# Controle de liberação dos módulos

## Objetivo
Permitir que o administrador controle, em cada módulo, se ele fica privado ou disponível e em qual dia do cronograma será liberado. O módulo “Aulas complementares” ficará configurado para o Dia 6.

## Implementação
- Adicionar aos módulos as configurações de visibilidade e dia de liberação, com valores seguros para os módulos atuais.
- Ajustar a área de membros para respeitar essas configurações, sem depender do nome ou da ordem do módulo.
- Exibir módulos privados de forma bloqueada e opaca, sem permitir acesso ao conteúdo.
- Atualizar o painel de módulos com controles para:
  - escolher entre “Disponível” e “Privado”;
  - selecionar o dia de liberação;
  - visualizar rapidamente a situação de cada módulo.
- Proteger também as páginas internas, impedindo abrir um módulo ou uma aula por link antes da liberação.
- Configurar “Aulas complementares” para liberar no Dia 6.

## Detalhes técnicos
- A regra será armazenada no banco para funcionar igualmente em todos os dispositivos.
- O dia será comparado ao cronograma individual já existente de cada aluno.
- Administradores continuarão podendo acessar e editar todo o conteúdo.
- Serão validados o painel e o fluxo do aluno em telas grandes e pequenas.
