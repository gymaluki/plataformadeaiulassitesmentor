<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Estrela-guia

Os membros aprendem a criar sites e a vendê-los para clientes pagantes

## Métrica

Aulas assistidas até o fim por semana
