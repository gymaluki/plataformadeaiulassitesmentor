# Roadmap

- [x] Conferir os caminhos ativos de falha de carregamento e gravação, preservando contas e permissões dos alunos.
- [x] Corrigir caminhos relacionados e repetir testes de falha e recuperação.

- [x] Revisar entrada, vídeo inicial, aulas, progresso e painel com uma conta de teste.
- [x] Corrigir as falhas reproduzidas e validar novamente.

- [x] Corrigir e validar a entrada e a tela preta para odilonm241@gmail.com.

1. [x] Corrigir falhas de login reportadas pelos usuários.
2. [x] Garantir a transição das senhas antigas e novas.
3. [x] Adicionar configurações de privacidade e dia de liberação aos módulos.
4. [x] Configurar Aulas complementares para liberar no Dia 6.
5. [x] Adicionar controles de privacidade e dia no painel admin.
6. [x] Aplicar e validar as travas na área do aluno e em links diretos.
