# Project rules

- After transferring a login session, never sign out the temporary client sharing its tokens; logout revokes the member's refresh token.
- The welcome video must offer a retry when its player fails to initialize; a loading failure must not silently mark the video as watched.
- Use AdminMobileNav on administrative pages with a desktop-only sidebar so navigation remains accessible on phones.
- Use useAsyncFeedback and LoadError for recoverable administrative requests so API errors and thrown failures cannot appear as empty successful results.
- Keep lesson and schedule read failures retryable in place, and wait for a confirmed welcome completion write before opening access, so transient network failures cannot invent progress or invalidate a session.