-- Drop the EAD-style tables if they interfere, or just adapt them. 
-- Since we want to "manter as aulas", we'll migrate carefully.

-- 1. Create Modules table (simplified)
CREATE TABLE IF NOT EXISTS public.app_modules (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  order_index INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE public.app_modules ENABLE ROW LEVEL SECURITY;

-- 2. Create Lessons table (simplified)
CREATE TABLE IF NOT EXISTS public.app_lessons (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  module_id UUID REFERENCES public.app_modules(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  video_url TEXT NOT NULL,
  duration_seconds INTEGER DEFAULT 0,
  order_index INTEGER DEFAULT 0,
  status TEXT DEFAULT 'published' CHECK (status IN ('published', 'draft')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE public.app_lessons ENABLE ROW LEVEL SECURITY;

-- 3. Create Progress table if not exists
CREATE TABLE IF NOT EXISTS public.app_progress (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  lesson_id UUID REFERENCES public.app_lessons(id) ON DELETE CASCADE,
  completed BOOLEAN DEFAULT false,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  UNIQUE(user_id, lesson_id)
);

ALTER TABLE public.app_progress ENABLE ROW LEVEL SECURITY;

-- 4. Migrate data from 'videos' to 'app_modules' and 'app_lessons'
DO $$
DECLARE
    m_record RECORD;
    new_module_id UUID;
BEGIN
    -- For each unique module name in videos
    FOR m_record IN SELECT DISTINCT module FROM public.videos LOOP
        -- Insert into app_modules
        INSERT INTO public.app_modules (title) VALUES (m_record.module)
        RETURNING id INTO new_module_id;

        -- Insert all videos of this module into app_lessons
        INSERT INTO public.app_lessons (module_id, title, description, video_url, order_index, status)
        SELECT new_module_id, title, description, video_url, sort_order, CASE WHEN is_published THEN 'published' ELSE 'draft' END
        FROM public.videos
        WHERE module = m_record.module;
    END LOOP;
END $$;

-- 5. Policies
-- Modules
CREATE POLICY "Students can view modules" ON public.app_modules FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Admins can manage modules" ON public.app_modules FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
);

-- Lessons
CREATE POLICY "Students can view published lessons" ON public.app_lessons FOR SELECT USING (
  auth.role() = 'authenticated' AND status = 'published'
);
CREATE POLICY "Admins can manage lessons" ON public.app_lessons FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
);

-- Progress
CREATE POLICY "Users can manage own progress" ON public.app_progress FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Admins can view all progress" ON public.app_progress FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
);

-- Ensure admin profile
INSERT INTO public.profiles (id, email, role)
SELECT id, email, 'admin' FROM auth.users WHERE email = 'andreyhenrzp@gmail.com'
ON CONFLICT (id) DO UPDATE SET role = 'admin';
