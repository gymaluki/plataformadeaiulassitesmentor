-- 1. Limpar módulos duplicados e manter apenas os necessários
DELETE FROM public.app_modules WHERE title IN ('Módulo 1: O Início', 'Comece aqui');

-- 2. Criar os módulos limpos
INSERT INTO public.app_modules (id, title, order_index) VALUES 
('00000000-0000-0000-0000-000000000001', 'Módulo 1: O Início', 0),
('00000000-0000-0000-0000-000000000002', 'Comece aqui', 1);

-- 3. Vincular todas as aulas conhecidas ao Módulo 1 e garantir status 'published'
-- Usamos UPDATE com base em padrões do video_url para identificar as aulas
UPDATE public.app_lessons SET module_id = '00000000-0000-0000-0000-000000000001', status = 'published' WHERE video_url LIKE '%acb456ntp7h%';
UPDATE public.app_lessons SET module_id = '00000000-0000-0000-0000-000000000001', status = 'published' WHERE video_url LIKE '%glkyt3kgo2a%';
UPDATE public.app_lessons SET module_id = '00000000-0000-0000-0000-000000000001', status = 'published' WHERE video_url LIKE '%bkdj7i3bv1p%';
UPDATE public.app_lessons SET module_id = '00000000-0000-0000-0000-000000000001', status = 'published' WHERE video_url LIKE '%983dmnvf4el%';
UPDATE public.app_lessons SET module_id = '00000000-0000-0000-0000-000000000001', status = 'published' WHERE video_url LIKE '%32czla5ouy3%';
UPDATE public.app_lessons SET module_id = '00000000-0000-0000-0000-000000000001', status = 'published' WHERE video_url LIKE '%re3qtr71lp%';
UPDATE public.app_lessons SET module_id = '00000000-0000-0000-0000-000000000001', status = 'published' WHERE video_url LIKE '%v4kfxk4d63%';

-- 4. Forçar as políticas de RLS para garantir acesso total de leitura
DROP POLICY IF EXISTS "Public can view modules" ON public.app_modules;
CREATE POLICY "Public can view modules" ON public.app_modules FOR SELECT USING (true);

DROP POLICY IF EXISTS "Public can view lessons" ON public.app_lessons;
CREATE POLICY "Public can view lessons" ON public.app_lessons FOR SELECT USING (true);

-- 5. Garantir que a tabela de progresso também aceite acessos (necessário para o Player)
DROP POLICY IF EXISTS "Anyone can manage own progress" ON public.app_progress;
CREATE POLICY "Anyone can manage own progress" ON public.app_progress FOR ALL USING (true) WITH CHECK (true);
