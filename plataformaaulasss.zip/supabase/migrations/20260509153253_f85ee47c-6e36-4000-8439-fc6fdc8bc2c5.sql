DROP POLICY IF EXISTS "Users can delete their own progress" ON public.lesson_progress;
DROP POLICY IF EXISTS "Users can insert their own progress" ON public.lesson_progress;
DROP POLICY IF EXISTS "Users can view their own progress" ON public.lesson_progress;
DROP POLICY IF EXISTS "Admins can manage roles" ON public.user_roles;
DROP POLICY IF EXISTS "Admins can view roles" ON public.user_roles;
DROP POLICY IF EXISTS "Only owner Gmail can create videos" ON public.videos;
DROP POLICY IF EXISTS "Only owner Gmail can update videos" ON public.videos;
DROP POLICY IF EXISTS "Only owner Gmail can delete videos" ON public.videos;
DROP POLICY IF EXISTS "Only owner Gmail can upload video files" ON storage.objects;
DROP POLICY IF EXISTS "Only owner Gmail can update video files" ON storage.objects;
DROP POLICY IF EXISTS "Only owner Gmail can delete video files" ON storage.objects;

CREATE POLICY "Users can view their own progress"
ON public.lesson_progress
FOR SELECT
TO authenticated
USING ((select auth.uid()) is not null AND (select auth.uid()) = user_id);

CREATE POLICY "Users can insert their own progress"
ON public.lesson_progress
FOR INSERT
TO authenticated
WITH CHECK ((select auth.uid()) is not null AND (select auth.uid()) = user_id);

CREATE POLICY "Users can delete their own progress"
ON public.lesson_progress
FOR DELETE
TO authenticated
USING ((select auth.uid()) is not null AND (select auth.uid()) = user_id);

CREATE POLICY "Admins can view roles"
ON public.user_roles
FOR SELECT
TO authenticated
USING ((select auth.uid()) is not null AND private.has_role((select auth.uid()), 'admin'::app_role));

CREATE POLICY "Admins can manage roles"
ON public.user_roles
FOR ALL
TO authenticated
USING ((select auth.uid()) is not null AND private.has_role((select auth.uid()), 'admin'::app_role))
WITH CHECK ((select auth.uid()) is not null AND private.has_role((select auth.uid()), 'admin'::app_role));

CREATE POLICY "Only owner Gmail can create videos"
ON public.videos
FOR INSERT
TO authenticated
WITH CHECK (
  (select auth.uid()) is not null
  AND lower(coalesce((select auth.jwt()) ->> 'email', '')) = 'andreyhenrzp@gmail.com'
);

CREATE POLICY "Only owner Gmail can update videos"
ON public.videos
FOR UPDATE
TO authenticated
USING (
  (select auth.uid()) is not null
  AND lower(coalesce((select auth.jwt()) ->> 'email', '')) = 'andreyhenrzp@gmail.com'
)
WITH CHECK (
  (select auth.uid()) is not null
  AND lower(coalesce((select auth.jwt()) ->> 'email', '')) = 'andreyhenrzp@gmail.com'
);

CREATE POLICY "Only owner Gmail can delete videos"
ON public.videos
FOR DELETE
TO authenticated
USING (
  (select auth.uid()) is not null
  AND lower(coalesce((select auth.jwt()) ->> 'email', '')) = 'andreyhenrzp@gmail.com'
);

CREATE POLICY "Only owner Gmail can upload video files"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  (select auth.uid()) is not null
  AND bucket_id = 'videos'
  AND lower(coalesce((select auth.jwt()) ->> 'email', '')) = 'andreyhenrzp@gmail.com'
);

CREATE POLICY "Only owner Gmail can update video files"
ON storage.objects
FOR UPDATE
TO authenticated
USING (
  (select auth.uid()) is not null
  AND bucket_id = 'videos'
  AND lower(coalesce((select auth.jwt()) ->> 'email', '')) = 'andreyhenrzp@gmail.com'
)
WITH CHECK (
  (select auth.uid()) is not null
  AND bucket_id = 'videos'
  AND lower(coalesce((select auth.jwt()) ->> 'email', '')) = 'andreyhenrzp@gmail.com'
);

CREATE POLICY "Only owner Gmail can delete video files"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  (select auth.uid()) is not null
  AND bucket_id = 'videos'
  AND lower(coalesce((select auth.jwt()) ->> 'email', '')) = 'andreyhenrzp@gmail.com'
);