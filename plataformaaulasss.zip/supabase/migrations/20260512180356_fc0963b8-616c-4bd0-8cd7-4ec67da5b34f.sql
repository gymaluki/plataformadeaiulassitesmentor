-- Remover a restrição de status das políticas para garantir que nada filtre as aulas
DROP POLICY IF EXISTS "Public can view lessons" ON public.app_lessons;
CREATE POLICY "Public can view lessons" ON public.app_lessons FOR SELECT USING (true);

-- Garantir que o bucket de vídeos seja público para leitura
UPDATE storage.buckets SET public = true WHERE id = 'videos';

-- Adicionar uma política de leitura pública para os objetos no bucket de vídeos se não existir
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'objects' 
        AND schemaname = 'storage' 
        AND policyname = 'Public Access to Videos'
    ) THEN
        CREATE POLICY "Public Access to Videos" ON storage.objects FOR SELECT USING (bucket_id = 'videos');
    END IF;
END $$;
