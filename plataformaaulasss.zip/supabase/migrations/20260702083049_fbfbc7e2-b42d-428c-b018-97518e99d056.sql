ALTER TABLE public.welcome_video_views
ADD COLUMN IF NOT EXISTS email text;

UPDATE public.welcome_video_views AS w
SET email = lower(p.email)
FROM public.profiles AS p
WHERE p.id = w.user_id
  AND p.email IS NOT NULL
  AND (w.email IS NULL OR w.email = '');

CREATE UNIQUE INDEX IF NOT EXISTS welcome_video_views_user_id_unique
ON public.welcome_video_views (user_id);

CREATE INDEX IF NOT EXISTS welcome_video_views_email_idx
ON public.welcome_video_views (lower(email))
WHERE email IS NOT NULL;

CREATE OR REPLACE FUNCTION public.has_watched_welcome_video(_user_id uuid, _email text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.welcome_video_views w
    LEFT JOIN public.profiles p ON p.id = w.user_id
    WHERE w.user_id = _user_id
       OR (
         _email IS NOT NULL
         AND lower(_email) <> ''
         AND (
           lower(coalesce(w.email, '')) = lower(_email)
           OR lower(coalesce(p.email, '')) = lower(_email)
         )
       )
  )
$$;

CREATE OR REPLACE FUNCTION public.mark_welcome_video_watched(_user_id uuid, _email text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.welcome_video_views (user_id, email, watched_at)
  VALUES (_user_id, lower(nullif(_email, '')), now())
  ON CONFLICT (user_id)
  DO UPDATE SET
    email = coalesce(public.welcome_video_views.email, excluded.email),
    watched_at = public.welcome_video_views.watched_at;
END;
$$;

GRANT EXECUTE ON FUNCTION public.has_watched_welcome_video(uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.mark_welcome_video_watched(uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_watched_welcome_video(uuid, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.mark_welcome_video_watched(uuid, text) TO service_role;