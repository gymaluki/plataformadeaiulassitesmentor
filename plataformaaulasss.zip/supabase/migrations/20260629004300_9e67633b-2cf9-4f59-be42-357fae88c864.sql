CREATE TABLE public.welcome_video_views (
  user_id uuid PRIMARY KEY,
  watched_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.welcome_video_views TO authenticated;
GRANT ALL ON public.welcome_video_views TO service_role;
ALTER TABLE public.welcome_video_views ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage their own welcome view"
ON public.welcome_video_views
FOR ALL
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);