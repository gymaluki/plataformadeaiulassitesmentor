DELETE FROM public.app_progress WHERE lesson_id='326eb10b-5fce-4408-a273-ab60707e0e71';
DELETE FROM public.app_lessons WHERE id='326eb10b-5fce-4408-a273-ab60707e0e71';