ALTER TABLE public.app_modules
  ADD COLUMN IF NOT EXISTS is_private boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS release_day integer NOT NULL DEFAULT 1;

ALTER TABLE public.app_modules
  ADD CONSTRAINT app_modules_release_day_range
  CHECK (release_day BETWEEN 1 AND 365);

UPDATE public.app_modules
SET release_day = CASE
  WHEN lower(title) LIKE '%complementar%' THEN 6
  WHEN title ~* 'dia[[:space:]]*0*([1-9][0-9]*)' THEN
    LEAST(365, GREATEST(1, (regexp_match(title, 'dia[[:space:]]*0*([1-9][0-9]*)', 'i'))[1]::integer))
  ELSE LEAST(365, GREATEST(1, COALESCE(order_index, 0) + 1))
END;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.app_modules TO authenticated;
GRANT ALL ON public.app_modules TO service_role;