-- Remover qualquer status 'draft' ou similar e forçar tudo para 'published'
UPDATE public.app_lessons SET status = 'published';

-- Garantir que as tabelas sejam públicas para leitura
ALTER TABLE public.app_modules DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_lessons DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_modules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_lessons ENABLE ROW LEVEL SECURITY;

-- Recriar as políticas mais simples possíveis
DROP POLICY IF EXISTS "Public can view modules" ON public.app_modules;
CREATE POLICY "Public can view modules" ON public.app_modules FOR SELECT USING (true);

DROP POLICY IF EXISTS "Public can view lessons" ON public.app_lessons;
CREATE POLICY "Public can view lessons" ON public.app_lessons FOR SELECT USING (true);
