-- Drop existing select policies to avoid conflicts
DROP POLICY IF EXISTS "Anyone can view modules" ON public.app_modules;
DROP POLICY IF EXISTS "Anyone can view lessons" ON public.app_lessons;

-- Create new policies that allow access to everyone (public/anon/authenticated)
CREATE POLICY "Public can view modules" 
ON public.app_modules 
FOR SELECT 
USING (true);

CREATE POLICY "Public can view lessons" 
ON public.app_lessons 
FOR SELECT 
USING (status = 'published');

-- Also ensure progress can be tracked for anonymous/guest users if needed
ALTER TABLE public.app_progress ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Anyone can manage own progress" ON public.app_progress;
CREATE POLICY "Anyone can manage own progress" 
ON public.app_progress 
FOR ALL 
USING (true)
WITH CHECK (true);
