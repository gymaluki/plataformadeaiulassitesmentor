-- Allow anonymous users to view modules and lessons
DROP POLICY IF EXISTS "Students can view modules" ON public.app_modules;
CREATE POLICY "Anyone can view modules" ON public.app_modules FOR SELECT USING (true);

DROP POLICY IF EXISTS "Students can view published lessons" ON public.app_lessons;
CREATE POLICY "Anyone can view lessons" ON public.app_lessons FOR SELECT USING (status = 'published');

-- Allow anonymous users to manage their progress (using auth.uid() which works for anon sessions)
DROP POLICY IF EXISTS "Users can manage own progress" ON public.app_progress;
CREATE POLICY "Anyone can manage own progress" ON public.app_progress FOR ALL USING (auth.uid() = user_id OR auth.role() = 'anon');
