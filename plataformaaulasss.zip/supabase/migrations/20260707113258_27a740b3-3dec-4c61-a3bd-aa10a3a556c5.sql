CREATE OR REPLACE FUNCTION public.get_member_course_schedule()
RETURNS TABLE (
  member_email text,
  course_start_at timestamp with time zone,
  course_start_date date,
  current_course_date date,
  unlocked_days integer
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _user_id uuid := auth.uid();
  _email text;
  _role text;
  _first_profile_at timestamp with time zone;
  _first_attempt_at timestamp with time zone;
  _first_release_at timestamp with time zone;
  _anchor timestamp with time zone;
BEGIN
  IF _user_id IS NULL THEN
    RETURN;
  END IF;

  SELECT lower(nullif(p.email, '')), p.role
    INTO _email, _role
  FROM public.profiles p
  WHERE p.id = _user_id
  ORDER BY p.created_at ASC
  LIMIT 1;

  IF _email IS NULL THEN
    SELECT lower(nullif(u.email, ''))
      INTO _email
    FROM auth.users u
    WHERE u.id = _user_id;
  END IF;

  SELECT min(p.created_at)
    INTO _first_profile_at
  FROM public.profiles p
  WHERE p.id = _user_id
     OR (_email IS NOT NULL AND lower(coalesce(p.email, '')) = _email);

  IF _email IS NOT NULL THEN
    SELECT min(ar.first_attempt_at), min(ar.released_at)
      INTO _first_attempt_at, _first_release_at
    FROM public.access_requests ar
    WHERE lower(ar.email) = _email;
  END IF;

  _anchor := least(
    coalesce(_first_attempt_at, _first_release_at, _first_profile_at, now()),
    coalesce(_first_profile_at, _first_attempt_at, _first_release_at, now()),
    coalesce(_first_release_at, _first_attempt_at, _first_profile_at, now())
  );

  RETURN QUERY
  SELECT
    _email AS member_email,
    _anchor AS course_start_at,
    (timezone('America/Sao_Paulo', _anchor))::date AS course_start_date,
    (timezone('America/Sao_Paulo', now()))::date AS current_course_date,
    CASE
      WHEN _role = 'admin' THEN 99
      ELSE greatest(
        1,
        (((timezone('America/Sao_Paulo', now()))::date - (timezone('America/Sao_Paulo', _anchor))::date) + 1)::integer
      )
    END AS unlocked_days;
END;
$$;

REVOKE ALL ON FUNCTION public.get_member_course_schedule() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_member_course_schedule() TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_member_course_schedule() TO service_role;