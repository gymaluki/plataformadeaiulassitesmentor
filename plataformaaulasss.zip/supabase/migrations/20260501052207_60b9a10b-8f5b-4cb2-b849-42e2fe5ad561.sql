-- Create storage bucket for video files
INSERT INTO storage.buckets (id, name, public) 
VALUES ('videos', 'videos', true)
ON CONFLICT (id) DO NOTHING;

-- Policies for viewing videos (Public or Authenticated depending on requirements, here we use authenticated for security)
CREATE POLICY "Authenticated users can view videos"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'videos');

-- Policies for admin management (replace with actual role check)
CREATE POLICY "Admins can upload videos"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'videos' AND 
  (SELECT role FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin' LIMIT 1) = 'admin'
);

CREATE POLICY "Admins can update videos"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'videos' AND 
  (SELECT role FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin' LIMIT 1) = 'admin'
);

CREATE POLICY "Admins can delete videos"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'videos' AND 
  (SELECT role FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin' LIMIT 1) = 'admin'
);
