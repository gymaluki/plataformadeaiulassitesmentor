
-- Allow anyone to manage videos (admin gate is client-side via Lovable/admin route)
DROP POLICY IF EXISTS "Admins can create videos" ON public.videos;
DROP POLICY IF EXISTS "Admins can update videos" ON public.videos;
DROP POLICY IF EXISTS "Admins can delete videos" ON public.videos;

CREATE POLICY "Anyone can create videos" ON public.videos FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Anyone can update videos" ON public.videos FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Anyone can delete videos" ON public.videos FOR DELETE TO anon, authenticated USING (true);

-- Storage policies for videos bucket
DROP POLICY IF EXISTS "Admins can upload videos" ON storage.objects;
DROP POLICY IF EXISTS "Admins can update videos" ON storage.objects;
DROP POLICY IF EXISTS "Admins can delete videos" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can view videos" ON storage.objects;

CREATE POLICY "Anyone can view video files" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id = 'videos');
CREATE POLICY "Anyone can upload video files" ON storage.objects FOR INSERT TO anon, authenticated WITH CHECK (bucket_id = 'videos');
CREATE POLICY "Anyone can update video files" ON storage.objects FOR UPDATE TO anon, authenticated USING (bucket_id = 'videos') WITH CHECK (bucket_id = 'videos');
CREATE POLICY "Anyone can delete video files" ON storage.objects FOR DELETE TO anon, authenticated USING (bucket_id = 'videos');
