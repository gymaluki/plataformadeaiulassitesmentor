-- Liberar vídeo inicial (usando um UUID aleatório já que ele ainda não logou)
INSERT INTO public.welcome_video_views (user_id, email, watched_at) 
VALUES (gen_random_uuid(), 'robert.naso@gmail.com', now());

-- Liberar acesso (remover espera de 2h/6h)
INSERT INTO public.access_requests (email, first_attempt_at, released_at)
VALUES ('robert.naso@gmail.com', now(), now())
ON CONFLICT (email) DO UPDATE SET released_at = now();