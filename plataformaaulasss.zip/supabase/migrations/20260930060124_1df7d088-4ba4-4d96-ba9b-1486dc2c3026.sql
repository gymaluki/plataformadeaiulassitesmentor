INSERT INTO public.welcome_video_views (user_id, email, watched_at)
SELECT p.id, lower(trim(p.email)), now()
FROM public.profiles p
WHERE lower(trim(p.email)) = 'agathachristievenancia@gmail.com'
ON CONFLICT (user_id) DO UPDATE
SET watched_at = EXCLUDED.watched_at,
    email = EXCLUDED.email;

UPDATE public.access_requests
SET released_at = LEAST(released_at, now() - interval '1 minute'),
    updated_at = now()
WHERE lower(trim(email)) = 'agathachristievenancia@gmail.com';