REVOKE EXECUTE ON FUNCTION public.has_watched_welcome_video(uuid, text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.mark_welcome_video_watched(uuid, text) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.has_watched_welcome_video(uuid, text) FROM anon;
REVOKE EXECUTE ON FUNCTION public.mark_welcome_video_watched(uuid, text) FROM anon;
GRANT EXECUTE ON FUNCTION public.has_watched_welcome_video(uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.mark_welcome_video_watched(uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_watched_welcome_video(uuid, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.mark_welcome_video_watched(uuid, text) TO service_role;