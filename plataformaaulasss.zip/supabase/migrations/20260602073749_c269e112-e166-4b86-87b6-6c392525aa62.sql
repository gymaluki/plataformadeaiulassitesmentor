
-- Criar 3 novos módulos organizados
INSERT INTO public.app_modules (id, title, order_index) VALUES
  ('00000000-0000-0000-0000-000000000010', 'Parte 1: Como criar sites da forma certa sem erros + dicas', 1),
  ('00000000-0000-0000-0000-000000000011', 'Parte 2: Como customizar usando a extensão', 2),
  ('00000000-0000-0000-0000-000000000012', 'Parte 3: Como instalar a extensão pra computador e celular', 3)
ON CONFLICT (id) DO UPDATE SET title = EXCLUDED.title, order_index = EXCLUDED.order_index;

-- Parte 1: aulas de criação de sites e vendas
UPDATE public.app_lessons SET module_id = '00000000-0000-0000-0000-000000000010', order_index = 1 WHERE id = '932e53bd-63fc-4430-8a97-c13d29483d58';
UPDATE public.app_lessons SET module_id = '00000000-0000-0000-0000-000000000010', order_index = 2 WHERE id = '326eb10b-5fce-4408-a273-ab60707e0e71';
UPDATE public.app_lessons SET module_id = '00000000-0000-0000-0000-000000000010', order_index = 3 WHERE id = '4f6ab5e0-572b-487b-9b8c-aab806b06f67';
UPDATE public.app_lessons SET module_id = '00000000-0000-0000-0000-000000000010', order_index = 4 WHERE id = '91f7f3c2-af52-4a7c-aa11-f3f18548e6dc';
UPDATE public.app_lessons SET module_id = '00000000-0000-0000-0000-000000000010', order_index = 5 WHERE id = '7b169db4-d22f-41c8-a4ea-293ffba43253';
UPDATE public.app_lessons SET module_id = '00000000-0000-0000-0000-000000000010', order_index = 6 WHERE id = 'f87557e0-a835-4d56-8794-8d77e70aa844';
UPDATE public.app_lessons SET module_id = '00000000-0000-0000-0000-000000000010', order_index = 7 WHERE id = '4e847e9b-e43c-4e00-82ab-2285a09f57d9';

-- Parte 2: customizar com extensão
UPDATE public.app_lessons SET module_id = '00000000-0000-0000-0000-000000000011', order_index = 1 WHERE id = '22709466-7f2a-4502-b35b-476be4760c0d';

-- Parte 3: instalar extensão
UPDATE public.app_lessons SET module_id = '00000000-0000-0000-0000-000000000012', order_index = 1 WHERE id = 'd5a08aa5-7132-4c4f-9051-48536bc5f107';

-- Remover módulo antigo vazio
DELETE FROM public.app_modules WHERE id = '00000000-0000-0000-0000-000000000001';
