-- Primeiro, vamos garantir que os módulos existam e estejam na ordem certa
DO $$ 
DECLARE 
    m1_id UUID;
    m2_id UUID;
BEGIN 
    -- Criar ou atualizar o Módulo 1
    INSERT INTO app_modules (title, order_index) 
    VALUES ('Módulo 1: O Início', 0)
    ON CONFLICT (id) DO UPDATE SET title = EXCLUDED.title, order_index = 0
    RETURNING id INTO m1_id;

    -- Criar ou atualizar o Módulo 2
    INSERT INTO app_modules (title, order_index) 
    VALUES ('Comece aqui', 1)
    ON CONFLICT (id) DO UPDATE SET title = EXCLUDED.title, order_index = 1
    RETURNING id INTO m2_id;

    -- Atualizar todas as aulas para garantir que elas tenham os links de vídeo corretos e status 'published'
    -- Aula 1
    UPDATE app_lessons SET 
        title = 'Como criar sites e modificaçoes da forma certa.',
        video_url = 'https://auemrbfxurkfkywiypkx.supabase.co/storage/v1/object/public/videos/acb456ntp7h-1777770531144.mp4',
        status = 'published',
        order_index = 1,
        module_id = m1_id
    WHERE video_url LIKE '%acb456ntp7h%';

    -- Aula 2
    UPDATE app_lessons SET 
        title = 'Parte 2. Como criar sites e modificaçoes da forma certa..',
        video_url = 'https://auemrbfxurkfkywiypkx.supabase.co/storage/v1/object/public/videos/glkyt3kgo2a-1777770891136.mp4',
        status = 'published',
        order_index = 2,
        module_id = m1_id
    WHERE video_url LIKE '%glkyt3kgo2a%';

    -- Aula 3
    UPDATE app_lessons SET 
        title = 'Criar uma Empresa forte (marca pessoal) para venda do seu trabalho.',
        video_url = 'https://auemrbfxurkfkywiypkx.supabase.co/storage/v1/object/public/videos/bkdj7i3bv1p-1777771348760.mp4',
        status = 'published',
        order_index = 3,
        module_id = m1_id
    WHERE video_url LIKE '%bkdj7i3bv1p%';

    -- Aula 4
    UPDATE app_lessons SET 
        title = 'Aquecimento Whastapp bussines, Instagram + Dicas.',
        video_url = 'https://auemrbfxurkfkywiypkx.supabase.co/storage/v1/object/public/videos/983dmnvf4el-1777771485967.mp4',
        status = 'published',
        order_index = 4,
        module_id = m1_id
    WHERE video_url LIKE '%983dmnvf4el%';

    -- Aula 5
    UPDATE app_lessons SET 
        title = 'Funil de vendas (Chamados)',
        video_url = 'https://auemrbfxurkfkywiypkx.supabase.co/storage/v1/object/public/videos/32czla5ouy3-1777771677538.mp4',
        status = 'published',
        order_index = 5,
        module_id = m1_id
    WHERE video_url LIKE '%32czla5ouy3%';

    -- Aula 6
    UPDATE app_lessons SET 
        title = 'Como instalar a extensão lovable infinito axionfly',
        video_url = 'https://auemrbfxurkfkywiypkx.supabase.co/storage/v1/object/public/videos/re3qtr71lp-1778339051059.mp4',
        status = 'published',
        order_index = 6,
        module_id = m1_id
    WHERE video_url LIKE '%re3qtr71lp%';

    -- Aula 7
    UPDATE app_lessons SET 
        title = 'Como usar a extensão lovable infinito + dicas + duvidas',
        video_url = 'https://auemrbfxurkfkywiypkx.supabase.co/storage/v1/object/public/videos/v4kfxk4d63-1778340307346.mp4',
        status = 'published',
        order_index = 7,
        module_id = m1_id
    WHERE video_url LIKE '%v4kfxk4d63%';

END $$;

-- Garantir que as políticas de RLS permitam a visualização pública
DROP POLICY IF EXISTS "Public can view modules" ON public.app_modules;
CREATE POLICY "Public can view modules" ON public.app_modules FOR SELECT USING (true);

DROP POLICY IF EXISTS "Public can view lessons" ON public.app_lessons;
CREATE POLICY "Public can view lessons" ON public.app_lessons FOR SELECT USING (true);
