create schema if not exists private;

create or replace function private.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.user_roles
    where user_id = _user_id
      and role = _role
  )
$$;

alter policy "Admins can view roles"
on public.user_roles
using (private.has_role(auth.uid(), 'admin'));

alter policy "Admins can manage roles"
on public.user_roles
using (private.has_role(auth.uid(), 'admin'))
with check (private.has_role(auth.uid(), 'admin'));

alter policy "Authenticated users can view published videos"
on public.videos
using (is_published = true or private.has_role(auth.uid(), 'admin'));

alter policy "Admins can create videos"
on public.videos
with check (private.has_role(auth.uid(), 'admin'));

alter policy "Admins can update videos"
on public.videos
using (private.has_role(auth.uid(), 'admin'))
with check (private.has_role(auth.uid(), 'admin'));

alter policy "Admins can delete videos"
on public.videos
using (private.has_role(auth.uid(), 'admin'));

drop function if exists public.has_role(uuid, public.app_role);