DROP POLICY IF EXISTS "Authenticated users can view published videos" ON public.videos;
CREATE POLICY "Anyone can view published videos"
ON public.videos FOR SELECT
TO anon, authenticated
USING (is_published = true OR private.has_role(auth.uid(), 'admin'::app_role));