DROP POLICY IF EXISTS "Members can view released lessons" ON public.app_lessons;
CREATE POLICY "Members can view released lessons"
ON public.app_lessons
FOR SELECT
TO authenticated
USING (
  public.is_admin(auth.uid())
  OR (
    status = 'published'
    AND module_id IS NOT NULL
    AND public.can_access_app_module(module_id)
  )
);