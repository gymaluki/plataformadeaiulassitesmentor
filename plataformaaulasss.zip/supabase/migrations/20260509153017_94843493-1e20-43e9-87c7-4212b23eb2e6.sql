DROP POLICY IF EXISTS "Anyone can create videos" ON public.videos;
DROP POLICY IF EXISTS "Anyone can update videos" ON public.videos;
DROP POLICY IF EXISTS "Anyone can delete videos" ON public.videos;
DROP POLICY IF EXISTS "Anyone can upload video files" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can update video files" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can delete video files" ON storage.objects;

CREATE POLICY "Only owner Gmail can create videos"
ON public.videos
FOR INSERT
TO authenticated
WITH CHECK (lower(coalesce(auth.jwt() ->> 'email', '')) = 'andreyhenrzp@gmail.com');

CREATE POLICY "Only owner Gmail can update videos"
ON public.videos
FOR UPDATE
TO authenticated
USING (lower(coalesce(auth.jwt() ->> 'email', '')) = 'andreyhenrzp@gmail.com')
WITH CHECK (lower(coalesce(auth.jwt() ->> 'email', '')) = 'andreyhenrzp@gmail.com');

CREATE POLICY "Only owner Gmail can delete videos"
ON public.videos
FOR DELETE
TO authenticated
USING (lower(coalesce(auth.jwt() ->> 'email', '')) = 'andreyhenrzp@gmail.com');

CREATE POLICY "Only owner Gmail can upload video files"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'videos'
  AND lower(coalesce(auth.jwt() ->> 'email', '')) = 'andreyhenrzp@gmail.com'
);

CREATE POLICY "Only owner Gmail can update video files"
ON storage.objects
FOR UPDATE
TO authenticated
USING (
  bucket_id = 'videos'
  AND lower(coalesce(auth.jwt() ->> 'email', '')) = 'andreyhenrzp@gmail.com'
)
WITH CHECK (
  bucket_id = 'videos'
  AND lower(coalesce(auth.jwt() ->> 'email', '')) = 'andreyhenrzp@gmail.com'
);

CREATE POLICY "Only owner Gmail can delete video files"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'videos'
  AND lower(coalesce(auth.jwt() ->> 'email', '')) = 'andreyhenrzp@gmail.com'
);