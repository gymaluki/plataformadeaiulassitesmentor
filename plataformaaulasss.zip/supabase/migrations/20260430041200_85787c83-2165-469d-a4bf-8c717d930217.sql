create type public.app_role as enum ('admin', 'student');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);

alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.user_roles
    where user_id = _user_id
      and role = _role
  )
$$;

create table public.videos (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  video_url text not null,
  module text not null default 'Comece aqui',
  sort_order integer not null default 0,
  is_published boolean not null default true,
  created_by uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.videos enable row level security;

create or replace function public.update_updated_at_column()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger update_videos_updated_at
before update on public.videos
for each row
execute function public.update_updated_at_column();

create policy "Admins can view roles"
on public.user_roles
for select
to authenticated
using (public.has_role(auth.uid(), 'admin'));

create policy "Admins can manage roles"
on public.user_roles
for all
to authenticated
using (public.has_role(auth.uid(), 'admin'))
with check (public.has_role(auth.uid(), 'admin'));

create policy "Authenticated users can view published videos"
on public.videos
for select
to authenticated
using (is_published = true or public.has_role(auth.uid(), 'admin'));

create policy "Admins can create videos"
on public.videos
for insert
to authenticated
with check (public.has_role(auth.uid(), 'admin'));

create policy "Admins can update videos"
on public.videos
for update
to authenticated
using (public.has_role(auth.uid(), 'admin'))
with check (public.has_role(auth.uid(), 'admin'));

create policy "Admins can delete videos"
on public.videos
for delete
to authenticated
using (public.has_role(auth.uid(), 'admin'));

create index videos_module_sort_idx on public.videos (module, sort_order, created_at);
create index user_roles_user_id_idx on public.user_roles (user_id);