CREATE OR REPLACE FUNCTION public.can_access_app_module(_module_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.app_modules m
    WHERE m.id = _module_id
      AND (
        public.is_admin(auth.uid())
        OR (
          m.is_private = false
          AND m.release_day <= COALESCE(
            (SELECT s.unlocked_days FROM public.get_member_course_schedule() s LIMIT 1),
            0
          )
        )
      )
  )
$$;

REVOKE ALL ON FUNCTION public.can_access_app_module(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_access_app_module(uuid) TO authenticated, service_role;

DROP POLICY IF EXISTS "Public can view lessons" ON public.app_lessons;
CREATE POLICY "Members can view released lessons"
ON public.app_lessons
FOR SELECT
TO authenticated
USING (
  status = 'published'
  AND module_id IS NOT NULL
  AND public.can_access_app_module(module_id)
);