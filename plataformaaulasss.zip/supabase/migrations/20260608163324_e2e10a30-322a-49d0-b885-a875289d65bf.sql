-- Adiciona a chave estrangeira se ela não existir
DO $$ 
BEGIN 
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.table_constraints 
        WHERE constraint_name = 'app_lessons_module_id_fkey'
    ) THEN
        ALTER TABLE public.app_lessons 
        ADD CONSTRAINT app_lessons_module_id_fkey 
        FOREIGN KEY (module_id) REFERENCES public.app_modules(id) 
        ON DELETE CASCADE;
    END IF;
END $$;

-- Garante que o usuário admin tenha permissões
GRANT ALL ON public.app_lessons TO authenticated;
GRANT ALL ON public.app_modules TO authenticated;
GRANT ALL ON public.app_lessons TO service_role;
GRANT ALL ON public.app_modules TO service_role;
