CREATE TABLE public.access_requests (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  email text NOT NULL UNIQUE,
  first_attempt_at timestamptz NOT NULL DEFAULT now(),
  released_at timestamptz NOT NULL DEFAULT (now() + interval '9 hours'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT ALL ON public.access_requests TO service_role;

ALTER TABLE public.access_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "service role only" ON public.access_requests FOR ALL USING (false) WITH CHECK (false);