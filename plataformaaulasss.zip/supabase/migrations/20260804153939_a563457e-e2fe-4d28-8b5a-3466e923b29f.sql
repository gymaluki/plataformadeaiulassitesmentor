-- Libera acesso para pbia862@gmail.com
INSERT INTO public.access_requests (email, released_at) 
VALUES ('pbia862@gmail.com', now()) 
ON CONFLICT (email) DO UPDATE SET released_at = now();

-- Marca vídeo como assistido para pbia862@gmail.com
-- Como a tabela usa user_id (uuid) como PK, e não temos o ID real ainda, 
-- inserimos com um ID aleatório já que o sistema parece aceitar o e-mail como identificador secundário
INSERT INTO public.welcome_video_views (user_id, email, watched_at) 
VALUES (gen_random_uuid(), 'pbia862@gmail.com', now());
