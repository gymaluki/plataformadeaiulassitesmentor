import { createClient } from "https://esm.sh/@supabase/supabase-js@2.105.1";
import { z } from "https://esm.sh/zod@3.25.76";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const memberLoginSchema = z.object({
  email: z.string().trim().email().max(255),
  password: z.string().min(1).max(256),
});

const ADMIN_EMAIL = "andreyhenriquev4@gmail.com";
const LEGACY_PASSWORD = "projeto123456";
const NEW_PASSWORD = "projeto";
// Meia-noite de 31/08/2026 no horário de Brasília (UTC-3)
const NEW_PASSWORD_CUTOFF = new Date("2026-08-31T03:00:00Z");

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const parsed = memberLoginSchema.safeParse(await req.json());
    if (!parsed.success) {
      return new Response(JSON.stringify({ error: "Preencha e-mail e senha da plataforma." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !anonKey || !serviceRoleKey) {
      throw new Error("Configuração de acesso incompleta.");
    }

    const email = parsed.data.email.toLowerCase();
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Recarregue a página e tente entrar novamente." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const { data: authData, error: authError } = await userClient.auth.getUser();
    if (authError || !authData.user?.id) {
      return new Response(JSON.stringify({ error: "Sessão inválida. Recarregue a página e tente entrar novamente." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const userId = authData.user.id;
    const isAdmin = email === ADMIN_EMAIL;

    // Descobre se esse Gmail já era cadastrado antes da meia-noite (usuário antigo).
    const { data: existing } = await supabase
      .from("access_requests")
      .select("email, first_attempt_at, created_at")
      .eq("email", email)
      .maybeSingle();

    const anchor = existing?.first_attempt_at ?? existing?.created_at ?? null;
    const isBeforePasswordChange = new Date() < NEW_PASSWORD_CUTOFF;
    // Até a virada, todo primeiro acesso ainda pertence à regra antiga. Depois
    // dela, somente quem já possuía registro anterior mantém a senha antiga.
    const isLegacyMember = isBeforePasswordChange
      || (Boolean(existing) && (!anchor || new Date(anchor) < NEW_PASSWORD_CUTOFF));

    // Normaliza a senha (espaços e maiúsculas) para evitar erros de digitação.
    const normalizedInput = parsed.data.password.replace(/\s+/g, "").toLowerCase();
    const expected = isAdmin || isLegacyMember ? LEGACY_PASSWORD : NEW_PASSWORD;
    const accepted = isAdmin || isLegacyMember
      ? [LEGACY_PASSWORD, NEW_PASSWORD]
      : [NEW_PASSWORD];

    if (!accepted.includes(normalizedInput)) {
      return new Response(
        JSON.stringify({ error: `Senha incorreta. A senha da plataforma é: ${expected}` }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Registra o primeiro acesso desse Gmail (usado como âncora do cronograma de dias).
    if (!isAdmin && !existing) {
      const nowIso = new Date().toISOString();
      await supabase
        .from("access_requests")
        .insert({ email, released_at: nowIso, first_attempt_at: nowIso });
    }


    const role = isAdmin ? "admin" : "student";

    const profileResult = await supabase
      .from("profiles")
      .upsert({ id: userId, email, role }, { onConflict: "id" });

    if (profileResult.error) throw profileResult.error;

    if (role === "admin") {
      const roleResult = await supabase
        .from("user_roles")
        .upsert({ user_id: userId, role: "admin" }, { onConflict: "user_id,role" });

      if (roleResult.error) throw roleResult.error;
    }

    return new Response(JSON.stringify({ email, role }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Erro inesperado.";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
