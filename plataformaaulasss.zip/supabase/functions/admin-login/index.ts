import { createClient } from "https://esm.sh/@supabase/supabase-js@2.105.1";
import { z } from "https://esm.sh/zod@3.25.76";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const adminLoginSchema = z.object({
  email: z.string().trim().email().max(255),
  password: z.string().min(1).max(128),
});

const ADMIN_EMAIL = "andreyhenriquev4@gmail.com";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const parsed = adminLoginSchema.safeParse(await req.json());
    if (!parsed.success) {
      return new Response(JSON.stringify({ error: "Preencha email e senha do admin." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const email = parsed.data.email.toLowerCase();
    if (email !== ADMIN_EMAIL) {
      return new Response(JSON.stringify({ error: "Apenas o Gmail admin autorizado pode abrir o painel." }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const adminPassword = Deno.env.get("ADMIN_PASSWORD");

    if (!adminPassword) {
      throw new Error("Configuração de admin incompleta.");
    }

    if (parsed.data.password !== adminPassword) {
      return new Response(JSON.stringify({ error: "Senha da mentoria incorreta." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Abra o painel admin de novo e tente entrar." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !anonKey || !serviceRoleKey) {
      throw new Error("Configuração de admin incompleta.");
    }

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const { data: authData, error: authError } = await userClient.auth.getUser();
    if (authError || !authData.user?.id) {
      return new Response(JSON.stringify({ error: "Sessão inválida. Recarregue a página e tente de novo." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const sessionAdminId = authData.user.id;

    const sessionProfile = await supabase
      .from("profiles")
      .upsert({ id: sessionAdminId, email, role: "admin" }, { onConflict: "id" });

    if (sessionProfile.error) throw sessionProfile.error;

    const sessionRole = await supabase
      .from("user_roles")
      .upsert({ user_id: sessionAdminId, role: "admin" }, { onConflict: "user_id,role" });

    if (sessionRole.error) throw sessionRole.error;

    const created = await supabase.auth.admin.createUser({
      email,
      password: adminPassword,
      email_confirm: true,
    });

    let adminUserId = created.data.user?.id;

    if (!adminUserId) {
      const users = await supabase.auth.admin.listUsers({ page: 1, perPage: 1000 });
      if (users.error) throw users.error;
      adminUserId = users.data.users.find((user) => user.email?.toLowerCase() === email)?.id;
      if (adminUserId) {
        const updated = await supabase.auth.admin.updateUserById(adminUserId, {
          password: adminPassword,
          email_confirm: true,
        });
        if (updated.error) throw updated.error;
      }
    }

    if (!adminUserId) {
      throw new Error("Não foi possível preparar o usuário admin.");
    }

    const profileResult = await supabase
      .from("profiles")
      .upsert({ id: adminUserId, email, role: "admin" }, { onConflict: "id" });

    if (profileResult.error) throw profileResult.error;

    const roleResult = await supabase
      .from("user_roles")
      .upsert({ user_id: adminUserId, role: "admin" }, { onConflict: "user_id,role" });

    if (roleResult.error) throw roleResult.error;

    return new Response(JSON.stringify({ email }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Erro inesperado.";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
