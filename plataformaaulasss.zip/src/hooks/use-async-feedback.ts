import { useCallback, useState } from "react";
import { useToast } from "@/hooks/use-toast";

/** Handle rejected requests as well as API error results without inventing empty data. */
export const useAsyncFeedback = () => {
  const { toast } = useToast();
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const run = useCallback(async (action: () => Promise<void>, message = "Não foi possível concluir. Tente novamente.") => {
    setPending(true);
    setError(null);
    try {
      await action();
      return true;
    } catch (cause) {
      console.error("[request] failed", cause);
      setError(message);
      toast({ title: message, variant: "destructive" });
      return false;
    } finally {
      setPending(false);
    }
  }, [toast]);
  return { run, error, pending };
};