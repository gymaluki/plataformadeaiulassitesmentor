import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { 
  LayoutDashboard, 
  BookOpen, 
  Users, 
  BarChart3, 
  Settings, 
  Plus, 
  Search,
  MoreVertical,
  LogOut,
  Video,
  Star
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

const AdminDashboard = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [courses, setCourses] = useState<any[]>([]);
  const [stats, setStats] = useState({
    totalStudents: 0,
    activeCourses: 0,
    totalRevenue: 0,
    avgRating: 4.9
  });

  useEffect(() => {
    const checkAdmin = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session || session.user.email !== 'andreyhenrzp@gmail.com') {
        navigate('/');
        return;
      }
      fetchData();
    };
    checkAdmin();
  }, [navigate]);

  const fetchData = async () => {
    const { data: coursesData } = await supabase
      .from('courses')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (coursesData) {
      setCourses(coursesData);
      setStats(prev => ({
        ...prev,
        activeCourses: coursesData.filter(c => c.status === 'published').length
      }));
    }
  };

  return (
    <div className="flex min-h-screen bg-[#0A0A0A]">
      {/* Sidebar */}
      <aside className="fixed inset-y-0 left-0 z-50 w-64 border-r border-white/5 bg-[#0F0F0F] hidden lg:block">
        <div className="flex h-16 items-center border-b border-white/5 px-6">
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground font-black">A</span>
            <span className="text-xl font-black tracking-tighter text-white">ADMIN</span>
          </div>
        </div>
        <nav className="p-4 space-y-2">
          {[
            { icon: LayoutDashboard, label: "Dashboard", active: true },
            { icon: BookOpen, label: "Cursos" },
            { icon: Users, label: "Alunos" },
            { icon: BarChart3, label: "Analytics" },
            { icon: Settings, label: "Configurações" },
          ].map((item, i) => (
            <Button
              key={i}
              variant="ghost"
              className={`w-full justify-start gap-3 h-11 px-4 text-sm font-medium ${item.active ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-white/5"}`}
            >
              <item.icon className="h-5 w-5" />
              {item.label}
            </Button>
          ))}
        </nav>
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <Button variant="ghost" className="w-full justify-start gap-3 text-muted-foreground hover:bg-white/5" onClick={() => supabase.auth.signOut()}>
            <LogOut className="h-5 w-5" />
            Sair
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 lg:pl-64">
        {/* Header */}
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-white/5 bg-[#0A0A0A]/80 px-6 backdrop-blur-xl lg:px-10">
          <h1 className="text-lg font-bold text-white">Visão Geral</h1>
          <div className="flex items-center gap-4">
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Buscar..." className="w-64 bg-white/5 border-white/10 pl-10 h-9" />
            </div>
            <Button variant="hero" size="sm" className="h-9 px-4">
              <Plus className="mr-2 h-4 w-4" /> Novo Curso
            </Button>
          </div>
        </header>

        <div className="p-6 lg:p-10">
          {/* Stats Grid */}
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4 mb-10">
            {[
              { label: "Total de Alunos", value: stats.totalStudents, icon: Users, color: "text-blue-500" },
              { label: "Cursos Ativos", value: stats.activeCourses, icon: BookOpen, color: "text-primary" },
              { label: "Receita do Mês", value: `R$ ${stats.totalRevenue.toFixed(2)}`, icon: BarChart3, color: "text-emerald-500" },
              { label: "Média de Avaliação", value: stats.avgRating, icon: Star, color: "text-yellow-500" },
            ].map((stat, i) => (
              <div key={i} className="rounded-2xl border border-white/5 bg-[#141414] p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className={`rounded-xl bg-white/5 p-3 ${stat.color}`}>
                    <stat.icon className="h-6 w-6" />
                  </span>
                </div>
                <p className="text-sm font-medium text-muted-foreground">{stat.label}</p>
                <p className="text-2xl font-black text-white mt-1">{stat.value}</p>
              </div>
            ))}
          </div>

          {/* Recent Courses Table */}
          <div className="rounded-2xl border border-white/5 bg-[#141414] overflow-hidden">
            <div className="p-6 border-b border-white/5 flex items-center justify-between">
              <h2 className="text-xl font-bold text-white">Meus Cursos</h2>
              <Button variant="ghost" className="text-primary hover:bg-primary/10">Ver todos</Button>
            </div>
            <Table>
              <TableHeader className="bg-white/[0.02]">
                <TableRow className="border-white/5 hover:bg-transparent">
                  <TableHead className="text-muted-foreground font-bold py-4">Curso</TableHead>
                  <TableHead className="text-muted-foreground font-bold">Status</TableHead>
                  <TableHead className="text-muted-foreground font-bold">Alunos</TableHead>
                  <TableHead className="text-muted-foreground font-bold">Receita</TableHead>
                  <TableHead className="text-right"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {courses.length === 0 ? (
                  <TableRow className="border-white/5 hover:bg-white/5">
                    <TableCell colSpan={5} className="py-10 text-center text-muted-foreground">
                      Nenhum curso criado ainda.
                    </TableCell>
                  </TableRow>
                ) : (
                  courses.map((course) => (
                    <TableRow key={course.id} className="border-white/5 hover:bg-white/5">
                      <TableCell className="py-4">
                        <div className="flex items-center gap-4">
                          <div className="h-12 w-20 shrink-0 overflow-hidden rounded-lg border border-white/10 bg-white/5">
                            {course.thumbnail_url && <img src={course.thumbnail_url} className="h-full w-full object-cover" />}
                          </div>
                          <div>
                            <p className="font-bold text-white">{course.title}</p>
                            <p className="text-xs text-muted-foreground mt-1">{course.level}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-black uppercase tracking-wider ${course.status === 'published' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-white/10 text-muted-foreground'}`}>
                          {course.status === 'published' ? 'Publicado' : 'Rascunho'}
                        </span>
                      </TableCell>
                      <TableCell className="text-white font-medium">0</TableCell>
                      <TableCell className="text-white font-medium">R$ 0,00</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-white">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;
