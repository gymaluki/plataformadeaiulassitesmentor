import { useEffect } from "react";

const AffiliateRedirect = () => {
  useEffect(() => {
    // Store the affiliate info in localStorage for 30 days
    const affiliateInfo = {
      id: "matheus_n",
      monthly: "https://pay.cakto.com.br/6u886t8_849513?affiliate=Lghn3ieU",
      lifetime: "https://pay.cakto.com.br/wcv2cko_849541?affiliate=LEGLH5Bd",
      timestamp: Date.now()
    };
    try {
      localStorage.setItem("affiliate_data", JSON.stringify(affiliateInfo));
    } finally {
      // Navigation must not depend on local storage being available.
      window.location.replace("/");
    }
  }, []);

  return null;
};

export default AffiliateRedirect;
