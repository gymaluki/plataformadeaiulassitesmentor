import { Sparkles, Zap, Users, ArrowRight } from "lucide-react";
import laptopImg from "@/assets/landing-laptop.jpg";
import cartImg from "@/assets/landing-cart.jpg";
import { useNavigate } from "react-router-dom";

export default function SelectedLanding() {
  const navigate = useNavigate();

  const handleEnter = () => {
    navigate("/login");
  };

  return (
    <div className="min-h-screen w-full bg-background text-foreground relative overflow-hidden flex items-center justify-center px-4 py-16">
      {/* Decorative blobs — contidos dentro do viewport */}
      <div
        className="pointer-events-none absolute -top-32 -left-32 w-[420px] h-[420px] max-w-[60vw] max-h-[60vw] rounded-full opacity-25 blur-[120px]"
        style={{ background: "hsl(270 91% 65%)" }}
      />
      <div
        className="pointer-events-none absolute -bottom-32 -right-32 w-[420px] h-[420px] max-w-[60vw] max-h-[60vw] rounded-full opacity-20 blur-[120px]"
        style={{ background: "hsl(280 95% 72%)" }}
      />

      {/* Radial mask */}
      <div className="absolute inset-0 bg-spotlight pointer-events-none" />

      {/* Content */}
      <div className="relative z-10 w-full max-w-5xl mx-auto text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-primary/20 bg-primary/10 text-primary text-sm font-medium mb-8 animate-fade-up" style={{ animationDelay: "0.1s" }}>
          <Sparkles className="w-4 h-4" />
          Convite exclusivo
        </div>

        {/* Headline */}
        <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight leading-[1.1] mb-6 animate-fade-up" style={{ animationDelay: "0.2s" }}>
          Você foi um dos{" "}
          <span className="text-gradient">8 selecionados</span>
        </h1>

        {/* Subtitle */}
        <p className="text-lg sm:text-xl text-muted-foreground leading-relaxed mb-10 animate-fade-up" style={{ animationDelay: "0.3s" }}>
          a entrar no projeto de criação de loja online com a gente diretamente da live. Parabéns, seja muito bem-vindo.
        </p>

        {/* Feature pills */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-10 animate-fade-up" style={{ animationDelay: "0.4s" }}>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-card border border-border/50 text-sm text-foreground">
            <Zap className="w-4 h-4 text-primary" />
            Acesso imediato
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-card border border-border/50 text-sm text-foreground">
            <Users className="w-4 h-4 text-primary" />
            Grupo fechado
          </div>
        </div>

        {/* Image cards — dentro do enquadro */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 mb-12 animate-fade-up" style={{ animationDelay: "0.45s" }}>
          <div className="relative rounded-2xl overflow-hidden border border-primary/20 bg-card/40 aspect-[4/3] shadow-[0_20px_60px_-30px_hsla(270,91%,65%,0.5)]">
            <img src={laptopImg} alt="Painel de loja online" loading="lazy" width={1024} height={768} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent" />
          </div>
          <div className="relative rounded-2xl overflow-hidden border border-primary/20 bg-card/40 aspect-[4/3] shadow-[0_20px_60px_-30px_hsla(280,95%,72%,0.5)]">
            <img src={cartImg} alt="Loja online neon" loading="lazy" width={1024} height={768} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent" />
          </div>
        </div>

        {/* Prova social */}
        <div className="mb-10 animate-fade-up" style={{ animationDelay: "0.5s" }}>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-primary/20 bg-primary/10 text-primary text-xs font-semibold tracking-wider uppercase mb-4">
            Prova social
          </div>
          <p className="font-display text-3xl sm:text-4xl font-bold">
            +3.247 <span className="text-gradient">lojas</span> já criadas
          </p>
        </div>

        {/* CTA */}
        <button
          onClick={handleEnter}
          className="group inline-flex items-center gap-3 px-8 py-4 rounded-2xl bg-primary text-primary-foreground font-semibold text-lg shadow-glow hover:shadow-[0_10px_50px_-10px_hsla(270,91%,65%,0.6)] transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] animate-fade-up"
          style={{ animationDelay: "0.5s" }}
        >
          Entrar na plataforma
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
}
