import { Wrench } from "lucide-react";

const Maintenance = () => {
  return (
    <div className="min-h-screen bg-[#0A0A0B] flex flex-col items-center justify-center p-4 text-center">
      <div className="bg-[#1A1A1C] p-8 rounded-2xl border border-white/10 max-w-md w-full animate-in fade-in zoom-in duration-500">
        <div className="bg-yellow-500/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
          <Wrench className="w-8 h-8 text-yellow-500 animate-pulse" />
        </div>
        <h1 className="text-2xl font-bold text-white mb-4">Estamos em Manutenção</h1>
        <p className="text-gray-400 mb-6 leading-relaxed">
          Já estamos arrumando tudo! Estamos subindo aulas novas e melhorias para você.
        </p>
        <div className="text-sm text-yellow-500 font-medium">
          Voltamos em instantes.
        </div>
      </div>
    </div>
  );
};

export default Maintenance;
