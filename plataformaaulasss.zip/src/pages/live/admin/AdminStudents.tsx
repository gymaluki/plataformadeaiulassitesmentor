import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { BookOpen, LayoutDashboard, Users, LogOut, KeyRound } from "lucide-react";
import { isAdminUser } from "@/lib/admin-access";
import { useAsyncFeedback } from "@/hooks/use-async-feedback";
import { LoadError } from "@/components/live/LoadError";
import { AdminMobileNav } from "@/components/live/AdminMobileNav";

const AdminStudents = () => {
  const navigate = useNavigate();
  const { run, error: requestError } = useAsyncFeedback();
  const [students, setStudents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAdmin = async () => {
      await run(async () => {
      try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/login?admin=1");
        return;
      }

      const admin = await isAdminUser(session.user.id);
      if (!admin) {
        await supabase.auth.signOut();
        navigate("/login?admin=1");
        return;
      }
      
      await fetchStudents();
      } finally { setLoading(false); }
      }, "Não foi possível concluir a solicitação. Tente novamente.");
    };
    checkAdmin();
  }, [navigate]);

  const fetchStudents = async () => {
      await run(async () => {
      try {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("role", "student")
      .order("created_at", { ascending: false });
    if (error) throw error;
    setStudents(data || []);
    setLoading(false);
      } finally { setLoading(false); }
      }, "Não foi possível concluir a solicitação. Tente novamente.");
  };

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="hidden w-64 shrink-0 border-r border-border bg-card p-6 md:flex flex-col">
        <div className="mb-10">
          <h1 className="text-xl font-black tracking-tighter text-foreground">PROJETO</h1>
          <p className="text-[10px] font-bold text-primary uppercase tracking-widest mt-1">Painel Admin</p>
        </div>
        <nav className="flex-1 space-y-2">
          <Button variant="ghost" onClick={() => navigate("/admin/modulos")} className="w-full justify-start gap-3 text-muted-foreground hover:bg-white/5">
            <BookOpen className="h-5 w-5" />
            Módulos
          </Button>
          <Button variant="ghost" onClick={() => navigate("/admin/aulas")} className="w-full justify-start gap-3 text-muted-foreground hover:bg-white/5">
            <LayoutDashboard className="h-5 w-5" />
            Aulas
          </Button>
          <Button variant="ghost" className="w-full justify-start gap-3 bg-primary/10 text-primary">
            <Users className="h-5 w-5" />
            Alunos
          </Button>
          <Button variant="ghost" onClick={() => navigate("/admin/liberacoes")} className="w-full justify-start gap-3 text-muted-foreground hover:bg-white/5">
            <KeyRound className="h-5 w-5" />
            Liberações
          </Button>
        </nav>
        <Button variant="ghost" onClick={() => navigate("/")} className="mt-auto justify-start gap-3 text-muted-foreground">
          <LogOut className="h-5 w-5" />
          Sair do Admin
        </Button>
      </aside>

      <main className="min-w-0 flex-1 p-4 sm:p-6 lg:p-10">
        <AdminMobileNav />
        {requestError && <LoadError message={requestError} retry={() => window.location.reload()} />}
        <header className="mb-10 flex items-center justify-between">
          <h2 className="text-3xl font-bold">Alunos Matriculados</h2>
        </header>

        <div className="grid gap-6">
          <div className="rounded-xl border border-border bg-card overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-white/5 text-xs font-bold uppercase tracking-widest text-muted-foreground">
                <tr>
                  <th className="px-6 py-4">Nome / E-mail</th>
                  <th className="px-6 py-4">Data de Cadastro</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {students.map(student => (
                  <tr key={student.id} className="hover:bg-white/[0.02]">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-xs">
                          {student.email?.[0].toUpperCase()}
                        </div>
                        <span className="font-medium">{student.email}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">
                      {new Date(student.created_at).toLocaleDateString('pt-BR')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {students.length === 0 && !loading && <div className="p-10 text-center text-muted-foreground">Nenhum aluno cadastrado.</div>}
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminStudents;
