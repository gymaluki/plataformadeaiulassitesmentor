import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Plus, Edit3, Trash2, LayoutDashboard, BookOpen, Users, LogOut, Lock, CalendarDays } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { isAdminUser } from "@/lib/admin-access";
import { useAsyncFeedback } from "@/hooks/use-async-feedback";
import { LoadError } from "@/components/live/LoadError";
import { AdminMobileNav } from "@/components/live/AdminMobileNav";

const AdminModules = () => {
  const navigate = useNavigate();
  const { run, error: requestError } = useAsyncFeedback();
  const { toast } = useToast();
  const [modules, setModules] = useState<any[]>([]);
  const [newTitle, setNewTitle] = useState("");
  const [newReleaseDay, setNewReleaseDay] = useState(1);
  const [newIsPrivate, setNewIsPrivate] = useState(false);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<any>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editOrder, setEditOrder] = useState(0);
  const [editReleaseDay, setEditReleaseDay] = useState(1);
  const [editIsPrivate, setEditIsPrivate] = useState(false);

  useEffect(() => {
    const checkAdmin = async () => {
      await run(async () => {
      try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) { navigate("/login?admin=1"); return; }
      const admin = await isAdminUser(session.user.id);
      if (!admin) {
        toast({ title: "Acesso negado", description: `Sua conta (${session.user.email}) não tem permissão de admin.`, variant: "destructive" });
        await supabase.auth.signOut();
        navigate("/login?admin=1");
        return;
      }
      await fetchModules();
      } finally { setLoading(false); }
      }, "Não foi possível concluir a solicitação. Tente novamente.");
    };
    checkAdmin();
  }, [navigate]);

  const fetchModules = async () => {
      await run(async () => {
      try {
    const { data, error } = await supabase.from("app_modules").select("*").order("order_index", { ascending: true });
    if (error) throw error;
    setModules(data || []);
    setLoading(false);
      } finally { setLoading(false); }
      }, "Não foi possível concluir a solicitação. Tente novamente.");
  };

  const createModule = async () => {
      await run(async () => {
      try {
    if (!newTitle.trim()) return;
    const { error } = await supabase.from("app_modules").insert({
      title: newTitle.trim(),
      order_index: modules.length,
      release_day: Math.max(1, Number(newReleaseDay) || 1),
      is_private: newIsPrivate,
    });
    if (error) {
      toast({ title: "Erro ao criar módulo", description: error.message, variant: "destructive" });
    } else {
      setNewTitle("");
      setNewReleaseDay(1);
      setNewIsPrivate(false);
      await fetchModules();
      toast({ title: "Módulo criado" });
    }
      } finally { setLoading(false); }
      }, "Não foi possível concluir a solicitação. Tente novamente.");
  };

  const openEdit = (m: any) => {
    setEditing(m);
    setEditTitle(m.title);
    setEditOrder(m.order_index ?? 0);
    setEditReleaseDay(m.release_day ?? 1);
    setEditIsPrivate(Boolean(m.is_private));
  };

  const saveEdit = async () => {
      await run(async () => {
      try {
    if (!editing) return;
    const { error } = await supabase.from("app_modules").update({
      title: editTitle.trim(),
      order_index: Number(editOrder),
      release_day: Math.max(1, Number(editReleaseDay) || 1),
      is_private: editIsPrivate,
    }).eq("id", editing.id);
    if (error) {
      toast({ title: "Erro ao salvar", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Módulo atualizado" });
      setEditing(null);
      await fetchModules();
    }
      } finally { setLoading(false); }
      }, "Não foi possível concluir a solicitação. Tente novamente.");
  };

  const deleteModule = async (id: string) => {
      await run(async () => {
      try {
    if (!confirm("Excluir este módulo e todas as suas aulas?")) return;
    const { error: lessonsError } = await supabase.from("app_lessons").delete().eq("module_id", id);
    if (lessonsError) throw lessonsError;
    const { error } = await supabase.from("app_modules").delete().eq("id", id);
    if (error) toast({ title: "Erro ao excluir", description: error.message, variant: "destructive" });
    else { await fetchModules(); toast({ title: "Módulo excluído" }); }
      } finally { setLoading(false); }
      }, "Não foi possível concluir a solicitação. Tente novamente.");
  };

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="hidden w-64 shrink-0 border-r border-border bg-card p-6 md:flex flex-col">
        <div className="mb-10">
          <h1 className="text-xl font-black tracking-tighter text-foreground">PROJETO</h1>
          <p className="text-[10px] font-bold text-primary uppercase tracking-widest mt-1">Painel Admin</p>
        </div>
        <nav className="flex-1 space-y-2">
          <Button variant="ghost" className="w-full justify-start gap-3 bg-primary/10 text-primary">
            <BookOpen className="h-5 w-5" /> Módulos
          </Button>
          <Button variant="ghost" onClick={() => navigate("/admin/aulas")} className="w-full justify-start gap-3 text-muted-foreground hover:bg-white/5">
            <LayoutDashboard className="h-5 w-5" /> Aulas
          </Button>
          <Button variant="ghost" onClick={() => navigate("/admin/alunos")} className="w-full justify-start gap-3 text-muted-foreground hover:bg-white/5">
            <Users className="h-5 w-5" /> Alunos
          </Button>
        </nav>
        <Button variant="ghost" onClick={() => navigate("/")} className="mt-auto justify-start gap-3 text-muted-foreground">
          <LogOut className="h-5 w-5" /> Sair do Admin
        </Button>
      </aside>

      <main className="min-w-0 flex-1 p-4 sm:p-6 lg:p-10">
        <AdminMobileNav />
        {requestError && <LoadError message={requestError} retry={() => window.location.reload()} />}
        <header className="mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold">Gerenciar Módulos</h2>
          <p className="mt-2 text-sm text-muted-foreground">Controle quando cada conteúdo aparece para os alunos.</p>
          <div className="mt-6 grid gap-3 rounded-lg border border-border bg-card p-4 xl:grid-cols-[minmax(180px,1fr)_120px_auto_auto] xl:items-end">
            <div>
              <Label htmlFor="new-module">Nome do módulo</Label>
              <Input id="new-module" placeholder="Novo módulo..." value={newTitle} onChange={(e) => setNewTitle(e.target.value)} className="mt-2 bg-background" />
            </div>
            <div>
              <Label htmlFor="new-release-day">Liberar no dia</Label>
              <Input id="new-release-day" type="number" min={1} value={newReleaseDay} onChange={(e) => setNewReleaseDay(Number(e.target.value))} className="mt-2 bg-background" />
            </div>
            <div className="flex h-10 items-center gap-2">
              <Switch id="new-private" checked={newIsPrivate} onCheckedChange={setNewIsPrivate} />
              <Label htmlFor="new-private">Privado</Label>
            </div>
            <Button onClick={createModule} className="bg-primary text-primary-foreground">
              <Plus className="h-4 w-4 mr-2" /> Novo Módulo
            </Button>
          </div>
        </header>

        {loading ? (
          <div className="text-primary">Carregando...</div>
        ) : (
          <div className="grid min-w-0 grid-cols-1 gap-4">
            {modules.length === 0 && (
              <div className="rounded-lg border border-dashed border-border p-10 text-center text-muted-foreground">Nenhum módulo criado.</div>
            )}
            {modules.map((m) => (
              <div key={m.id} className={`flex flex-col gap-4 rounded-lg border border-border bg-card p-4 transition-all hover:border-primary/30 sm:flex-row sm:items-center sm:justify-between ${m.is_private ? "opacity-60" : ""}`}>
                <div className="flex min-w-0 items-center gap-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-white/5 font-mono text-sm font-bold text-muted-foreground">{m.order_index}</div>
                  <div className="min-w-0 flex-1">
                    <h3 className="truncate font-bold text-lg">{m.title}</h3>
                    <div className="mt-1 flex flex-wrap gap-2 text-xs">
                      <span className="inline-flex items-center gap-1 text-primary"><CalendarDays className="h-3.5 w-3.5" /> Dia {m.release_day ?? 1}</span>
                      {m.is_private && <span className="inline-flex items-center gap-1 text-muted-foreground"><Lock className="h-3.5 w-3.5" /> Privado</span>}
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" size="icon" onClick={() => openEdit(m)} className="text-muted-foreground hover:text-white">
                    <Edit3 className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => deleteModule(m.id)} className="text-muted-foreground hover:text-destructive">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Editar Módulo</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Título</Label>
              <Input value={editTitle} onChange={(e) => setEditTitle(e.target.value)} />
            </div>
            <div>
              <Label>Ordem</Label>
              <Input type="number" value={editOrder} onChange={(e) => setEditOrder(Number(e.target.value))} />
            </div>
            <div>
              <Label>Liberar no dia</Label>
              <Input type="number" min={1} value={editReleaseDay} onChange={(e) => setEditReleaseDay(Number(e.target.value))} />
            </div>
            <div className="flex items-center justify-between rounded-lg border border-border p-3">
              <div>
                <Label htmlFor="edit-private">Módulo privado</Label>
                <p className="mt-1 text-xs text-muted-foreground">Bloqueia o conteúdo para todos os alunos.</p>
              </div>
              <Switch id="edit-private" checked={editIsPrivate} onCheckedChange={setEditIsPrivate} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setEditing(null)}>Cancelar</Button>
            <Button onClick={saveEdit} className="bg-primary text-primary-foreground">Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminModules;
