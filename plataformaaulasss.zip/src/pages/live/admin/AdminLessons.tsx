import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Edit3, Trash2, LayoutDashboard, BookOpen, Users, LogOut, Upload, Youtube } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { isAdminUser } from "@/lib/admin-access";
import { useAsyncFeedback } from "@/hooks/use-async-feedback";
import { LoadError } from "@/components/live/LoadError";
import { AdminMobileNav } from "@/components/live/AdminMobileNav";

const AdminLessons = () => {
  const navigate = useNavigate();
  const { run, error: requestError } = useAsyncFeedback();
  const { toast } = useToast();
  const [lessons, setLessons] = useState<any[]>([]);
  const [modules, setModules] = useState<any[]>([]);
  const [selectedModuleId, setSelectedModuleId] = useState<string>("all");
  const [loading, setLoading] = useState(true);
  const [authorized, setAuthorized] = useState(false);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({ title: "", description: "", module_id: "", video_url: "", order_index: 0, status: "published" });
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  useEffect(() => {
    const checkAdmin = async () => {
      await run(async () => {
      try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) { navigate("/login?admin=1"); return; }
      const admin = await isAdminUser(session.user.id);
      if (!admin) {
        toast({ title: "Acesso negado", description: `Sua conta (${session.user.email}) não tem permissão de admin.`, variant: "destructive" });
        await supabase.auth.signOut();
        navigate("/login?admin=1");
        return;
      }
      setAuthorized(true);
      } finally { setLoading(false); }
      }, "Não foi possível concluir a solicitação. Tente novamente.");
    };
    checkAdmin();
  }, [navigate]);

  const fetchData = async () => {
      await run(async () => {
      try {
    const { data: modulesData, error: modulesError } = await supabase.from("app_modules").select("*").order("order_index");
    if (modulesError) throw modulesError;
    setModules(modulesData || []);
    let query = supabase.from("app_lessons").select("*, app_modules(title)").order("order_index", { ascending: true });
    if (selectedModuleId !== "all") query = query.eq("module_id", selectedModuleId);
    const { data: lessonsData, error: lessonsError } = await query;
    if (lessonsError) throw lessonsError;
    setLessons(lessonsData || []);
    setLoading(false);
      } finally { setLoading(false); }
      }, "Não foi possível concluir a solicitação. Tente novamente.");
  };

  useEffect(() => { if (authorized) void fetchData(); }, [selectedModuleId, authorized]);

  const openNew = () => {
    setEditing(null);
    setForm({ title: "", description: "", module_id: modules[0]?.id || "", video_url: "", order_index: lessons.length + 1, status: "published" });
    setVideoFile(null);
    setDialogOpen(true);
  };

  const openEdit = (lesson: any) => {
    setEditing(lesson);
    setForm({
      title: lesson.title || "",
      description: lesson.description || "",
      module_id: lesson.module_id || "",
      video_url: lesson.video_url || "",
      order_index: lesson.order_index ?? 0,
      status: lesson.status || "published",
    });
    setVideoFile(null);
    setDialogOpen(true);
  };

  const uploadVideo = async (): Promise<string | null> => {
    if (!videoFile) return form.video_url || null;
    setUploading(true);
    setUploadProgress(0);
    const ext = videoFile.name.split(".").pop();
    const path = `${Math.random().toString(36).slice(2)}-${Date.now()}.${ext}`;
    try {
    const { error } = await supabase.storage.from("videos").upload(path, videoFile, {
      cacheControl: "3600",
      upsert: false,
      contentType: videoFile.type,
    });
    setUploading(false);
    if (error) {
      toast({ title: "Erro no upload", description: error.message, variant: "destructive" });
      return null;
    }
    const { data } = supabase.storage.from("videos").getPublicUrl(path);
    return data.publicUrl;
    } finally { setUploading(false); }
  };

  const save = async () => {
      await run(async () => {
      try {
    if (!form.title.trim() || !form.module_id) {
      toast({ title: "Preencha título e módulo", variant: "destructive" });
      return;
    }

    try {
      let videoUrl = form.video_url;

      // Se houver um arquivo, ele tem prioridade sobre a URL digitada
      if (videoFile) {
        const uploadedUrl = await uploadVideo();
        if (!uploadedUrl) return; // O erro já foi mostrado no toast do upload
        videoUrl = uploadedUrl;
      }

      if (!videoUrl) {
        toast({ title: "É necessário enviar um vídeo ou colar um link", variant: "destructive" });
        return;
      }

      const payload = {
        title: form.title,
        description: form.description || null,
        module_id: form.module_id,
        video_url: videoUrl,
        order_index: Number(form.order_index) || 0,
        status: form.status,
      };

      let error;
      if (editing) {
        ({ error } = await supabase.from("app_lessons").update(payload).eq("id", editing.id));
      } else {
        ({ error } = await supabase.from("app_lessons").insert(payload));
      }

      if (error) throw error;

      toast({ title: editing ? "Aula atualizada" : "Aula criada" });
      setDialogOpen(false);
      await fetchData();
    } catch (error: any) {
      toast({ title: "Erro ao salvar aula", description: error.message, variant: "destructive" });
    }
      } finally { setLoading(false); }
      }, "Não foi possível concluir a solicitação. Tente novamente.");
  };

  const deleteLesson = async (id: string) => {
      await run(async () => {
      try {
    if (!confirm("Excluir aula?")) return;
    const { error } = await supabase.from("app_lessons").delete().eq("id", id);
    if (error) toast({ title: "Erro", description: error.message, variant: "destructive" });
    else await fetchData();
      } finally { setLoading(false); }
      }, "Não foi possível concluir a solicitação. Tente novamente.");
  };

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="hidden w-64 shrink-0 border-r border-border bg-card p-6 md:flex flex-col">
        <div className="mb-10">
          <h1 className="text-xl font-black tracking-tighter text-foreground">PROJETO</h1>
          <p className="text-[10px] font-bold text-primary uppercase tracking-widest mt-1">Painel Admin</p>
        </div>
        <nav className="flex-1 space-y-2">
          <Button variant="ghost" onClick={() => navigate("/admin/modulos")} className="w-full justify-start gap-3 text-muted-foreground hover:bg-white/5">
            <BookOpen className="h-5 w-5" /> Módulos
          </Button>
          <Button variant="ghost" className="w-full justify-start gap-3 bg-primary/10 text-primary">
            <Youtube className="h-5 w-5" /> Aulas
          </Button>
          <Button variant="ghost" onClick={() => navigate("/admin/alunos")} className="w-full justify-start gap-3 text-muted-foreground hover:bg-white/5">
            <Users className="h-5 w-5" /> Alunos
          </Button>
        </nav>
        <Button variant="ghost" onClick={() => navigate("/")} className="mt-auto justify-start gap-3 text-muted-foreground">
          <LogOut className="h-5 w-5" /> Sair do Admin
        </Button>
      </aside>

      <main className="min-w-0 flex-1 p-4 sm:p-6 lg:p-10">
        <AdminMobileNav />
        {requestError && <LoadError message={requestError} retry={() => window.location.reload()} />}
        <header className="mb-10 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 className="text-3xl font-bold">Gerenciar Aulas</h2>
            <div className="mt-4 w-64">
              <Select value={selectedModuleId} onValueChange={setSelectedModuleId}>
                <SelectTrigger className="bg-card"><SelectValue placeholder="Filtrar por módulo" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os módulos</SelectItem>
                  {modules.map(m => <SelectItem key={m.id} value={m.id}>{m.title}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <Button onClick={openNew} className="bg-primary text-primary-foreground">
            <Plus className="h-4 w-4 mr-2" /> Nova Aula
          </Button>
        </header>

        <div className="rounded-xl border border-border bg-card overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-white/5 text-xs font-bold uppercase tracking-widest text-muted-foreground">
              <tr>
                <th className="px-6 py-4">Título</th>
                <th className="px-6 py-4">Módulo</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {lessons.map(lesson => (
                <tr key={lesson.id} className="hover:bg-white/[0.02]">
                  <td className="px-6 py-4 font-medium">{lesson.title}</td>
                  <td className="px-6 py-4 text-sm text-muted-foreground">{lesson.app_modules?.title}</td>
                  <td className="px-6 py-4">
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${lesson.status === 'published' ? 'bg-primary/10 text-primary' : 'bg-white/10 text-muted-foreground'}`}>
                      {lesson.status === 'published' ? 'Publicada' : 'Rascunho'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-1">
                      <Button variant="ghost" size="icon" onClick={() => openEdit(lesson)} className="h-8 w-8 text-muted-foreground hover:text-white">
                        <Edit3 className="h-3.5 w-3.5" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => deleteLesson(lesson.id)} className="h-8 w-8 text-muted-foreground hover:text-destructive">
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {lessons.length === 0 && !loading && <div className="p-10 text-center text-muted-foreground">Nenhuma aula encontrada.</div>}
        </div>
      </main>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? "Editar Aula" : "Nova Aula"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Título</Label>
              <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </div>
            <div>
              <Label>Módulo</Label>
              <Select value={form.module_id} onValueChange={(v) => setForm({ ...form, module_id: v })}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>
                  {modules.map(m => <SelectItem key={m.id} value={m.id}>{m.title}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Descrição</Label>
              <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Ordem</Label>
                <Input type="number" value={form.order_index} onChange={(e) => setForm({ ...form, order_index: Number(e.target.value) })} />
              </div>
              <div>
                <Label>Status</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="published">Publicada</SelectItem>
                    <SelectItem value="draft">Rascunho</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-4 rounded-lg border border-border p-4 bg-white/5">
              <Label className="text-primary font-bold">Conteúdo da Aula (Vídeo)</Label>
              
              <div className="space-y-2">
                <Label className="text-xs">Opção 1: Upload de arquivo</Label>
                <div className="flex items-center gap-2">
                  <Input 
                    type="file" 
                    accept="video/*" 
                    onChange={(e) => setVideoFile(e.target.files?.[0] || null)} 
                    className="bg-background"
                  />
                  <Upload className="h-4 w-4 text-muted-foreground" />
                </div>
              </div>

              <div className="relative py-2">
                <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-border" /></div>
                <div className="relative flex justify-center text-xs uppercase"><span className="bg-card px-2 text-muted-foreground">OU</span></div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs">Opção 2: Link externo (YouTube, Vimeo, etc)</Label>
                <Input 
                  value={form.video_url} 
                  onChange={(e) => setForm({ ...form, video_url: e.target.value })} 
                  placeholder="https://www.youtube.com/watch?v=..." 
                  className="bg-background"
                />
              </div>

              {form.video_url && !videoFile && (
                <div className="mt-2 rounded bg-primary/10 p-2 border border-primary/20">
                  <p className="text-[10px] text-primary font-bold uppercase">URL Atual configurada:</p>
                  <p className="text-xs text-muted-foreground truncate">{form.video_url}</p>
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setDialogOpen(false)}>Cancelar</Button>
            <Button onClick={save} disabled={uploading} className="bg-primary text-primary-foreground">
              {uploading ? "Enviando..." : "Salvar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminLessons;
