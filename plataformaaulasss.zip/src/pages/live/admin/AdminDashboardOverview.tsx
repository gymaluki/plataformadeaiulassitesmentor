import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Line,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  ArrowUpRight,
  CalendarDays,
  ChevronDown,
  Clock,
  PlayCircle,
  Sparkles,
  Users,
  Wallet,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { isAdminUser } from "@/lib/admin-access";
import { useAsyncFeedback } from "@/hooks/use-async-feedback";
import { LoadError } from "@/components/live/LoadError";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const RANGES = ["Últimos 7 dias", "Últimos 30 dias", "Últimos 90 dias"] as const;

const nf = new Intl.NumberFormat("pt-BR");

const abbreviate = (value: number) =>
  value >= 1000 ? `${(value / 1000).toFixed(1)}k` : `${value}`;

type Row = { created_at: string | null };

const ChartTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl border border-border bg-popover/95 px-4 py-3 shadow-[var(--shadow-elevated)] backdrop-blur">
      <p className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">
        {label}
      </p>
      <div className="mt-2 space-y-1">
        {payload.map((item: any) => (
          <div key={item.dataKey} className="flex items-center gap-3 text-sm">
            <span
              className="h-2 w-2 rounded-full"
              style={{ background: item.stroke || item.color }}
            />
            <span className="text-muted-foreground">{item.name}</span>
            <span className="ml-auto font-bold text-foreground">
              {nf.format(item.value)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

const AdminDashboardOverview = () => {
  const navigate = useNavigate();
  const { run, error: requestError } = useAsyncFeedback();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState<string>(RANGES[1]);
  const [profiles, setProfiles] = useState<Row[]>([]);
  const [requests, setRequests] = useState<any[]>([]);
  const [views, setViews] = useState<Row[]>([]);
  const [lessons, setLessons] = useState<any[]>([]);
  const [barReady, setBarReady] = useState(false);

  useEffect(() => {
    const boot = async () => {
      await run(async () => {
      try {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (!session) {
        navigate("/login?admin=1");
        return;
      }
      if (!(await isAdminUser(session.user.id))) {
        toast({
          title: "Acesso negado",
          description: "Sua conta não tem permissão de admin.",
          variant: "destructive",
        });
        navigate("/login?admin=1");
        return;
      }

      const [p, r, v, l] = await Promise.all([
        supabase.from("profiles").select("created_at").order("created_at", { ascending: true }),
        supabase.from("access_requests").select("*").order("created_at", { ascending: false }),
        supabase.from("welcome_video_views").select("watched_at"),
        supabase.from("app_lessons").select("id, title, created_at, module_id").order("created_at", { ascending: false }).limit(6),
      ]);

      if (p.error || r.error || v.error || l.error) throw p.error || r.error || v.error || l.error;
      setProfiles((p.data as Row[]) || []);
      setRequests(r.data || []);
      setViews(((v.data as any[]) || []).map((x) => ({ created_at: x.watched_at })));
      setLessons(l.data || []);
      setLoading(false);
      setTimeout(() => setBarReady(true), 120);
      } finally { setLoading(false); }
      }, "Não foi possível concluir a solicitação. Tente novamente.");
    };
    boot();
  }, [navigate]);

  const days = range === RANGES[0] ? 7 : range === RANGES[2] ? 90 : 30;

  const series = useMemo(() => {
    const buckets: { date: string; alunos: number; liberacoes: number }[] = [];
    const step = days <= 7 ? 1 : days <= 30 ? 3 : 9;
    for (let i = days; i >= 0; i -= step) {
      const start = new Date();
      start.setHours(0, 0, 0, 0);
      start.setDate(start.getDate() - i);
      const end = new Date(start);
      end.setDate(end.getDate() + step);

      const inRange = (rows: any[]) =>
        rows.filter((row) => {
          if (!row.created_at) return false;
          const d = new Date(row.created_at);
          return d >= start && d < end;
        }).length;

      buckets.push({
        date: start.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" }),
        alunos: inRange(profiles),
        liberacoes: inRange(requests.filter((r) => r.approved || r.released_at)),
      });
    }
    return buckets;
  }, [profiles, requests, days]);

  const totalAlunos = profiles.length;
  const pendentes = requests.filter((r) => !(r.approved || r.released_at)).length;
  const liberados = requests.length - pendentes;
  const assistiram = views.length;
  const conclusao = totalAlunos ? Math.round((assistiram / totalAlunos) * 100) : 0;

  const distribution = [
    { name: "Acesso liberado", value: liberados, color: "hsl(var(--primary))" },
    { name: "Aguardando liberação", value: pendentes, color: "hsl(var(--accent))" },
    { name: "Sem solicitação", value: Math.max(totalAlunos - requests.length, 0), color: "hsl(0 0% 28%)" },
  ].filter((d) => d.value > 0);

  const distributionTotal = distribution.reduce((acc, d) => acc + d.value, 0) || 1;

  if (requestError) return <div className="min-h-screen bg-background p-6"><LoadError message={requestError} retry={() => window.location.reload()} /></div>;

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background text-muted-foreground">
        Carregando painel…
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-7xl space-y-10 px-5 py-10 sm:px-8 lg:py-14">
        {/* 1. Cabeçalho */}
        <header className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="text-3xl font-black tracking-tight text-foreground sm:text-4xl">
                Dashboard Axionfly
              </h1>
              <span className="inline-flex items-center gap-2 rounded-full border border-border bg-secondary px-3 py-1 text-xs font-semibold text-muted-foreground">
                <span className="h-2 w-2 animate-pulse rounded-full bg-primary" />
                Dados em tempo real
              </span>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              Visão geral de alunos, liberações e engajamento da plataforma.
            </p>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="rounded-xl border-border bg-card">
                <CalendarDays className="mr-2 h-4 w-4 text-primary" />
                {range}
                <ChevronDown className="ml-2 h-4 w-4 text-muted-foreground" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="rounded-xl">
              {RANGES.map((r) => (
                <DropdownMenuItem key={r} onClick={() => setRange(r)}>
                  {r}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </header>

        {/* 2. Cards de resumo */}
        <section className="grid gap-6 lg:grid-cols-4">
          <div className="rounded-3xl border border-border bg-gradient-to-br from-primary/20 via-primary/5 to-transparent p-7 transition-colors hover:from-primary/25 lg:col-span-2">
            <div className="flex items-center gap-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/20 text-primary">
                <Wallet className="h-4 w-4" />
              </span>
              <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-muted-foreground">
                Alunos ativos
              </p>
            </div>
            <p className="mt-6 text-5xl font-black tracking-tight text-foreground">
              {nf.format(totalAlunos)}
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              Contas criadas com acesso à plataforma
            </p>
            <div className="mt-6 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
              <div
                className="h-full rounded-full bg-primary transition-all duration-1000 ease-out"
                style={{ width: barReady ? `${Math.min(conclusao, 100)}%` : "0%" }}
              />
            </div>
            <p className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
              <span className="h-2 w-2 rounded-full bg-primary" />
              {conclusao}% concluíram o vídeo de boas-vindas
            </p>
          </div>

          {[
            { label: "Liberações pendentes", value: pendentes, icon: Clock, help: "Aguardando aprovação do admin" },
            { label: "Vídeos iniciais vistos", value: assistiram, icon: PlayCircle, help: "Alunos que finalizaram o onboarding" },
          ].map((card) => (
            <div
              key={card.label}
              className="rounded-3xl border border-border bg-card p-7 transition-colors hover:bg-secondary/60 "
            >
              <div className="flex items-start justify-between gap-4">
                <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-muted-foreground">
                  {card.label}
                </p>
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-secondary text-muted-foreground">
                  <card.icon className="h-4 w-4" />
                </span>
              </div>
              <p className="mt-6 text-4xl font-black tracking-tight text-foreground">
                {nf.format(card.value)}
              </p>
              <p className="mt-2 text-sm text-muted-foreground">{card.help}</p>
            </div>
          ))}
        </section>

        {/* 3. Fluxo + 4. Distribuição */}
        <section className="grid gap-6 lg:grid-cols-3">
          <div className="rounded-3xl border border-border bg-card p-7 lg:col-span-2">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="text-lg font-bold text-foreground">Fluxo de entradas</h2>
              <div className="flex items-center gap-5 text-xs text-muted-foreground">
                <span className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-primary" /> Novos alunos
                </span>
                <span className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-accent" /> Liberações
                </span>
              </div>
            </div>

            <div className="mt-8 h-[280px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={series} margin={{ top: 10, right: 8, left: -18, bottom: 0 }}>
                  <defs>
                    <linearGradient id="axFlow" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.45} />
                      <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid vertical={false} stroke="hsl(0 0% 100% / 0.06)" />
                  <XAxis
                    dataKey="date"
                    tickLine={false}
                    axisLine={false}
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                  />
                  <YAxis
                    tickLine={false}
                    axisLine={false}
                    width={48}
                    tickFormatter={(v: number) => abbreviate(v)}
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
                  />
                  <Tooltip content={<ChartTooltip />} cursor={{ stroke: "hsl(var(--primary))", strokeOpacity: 0.25 }} />
                  <Line
                    type="monotone"
                    dataKey="liberacoes"
                    name="Liberações"
                    stroke="hsl(var(--accent))"
                    strokeWidth={1.5}
                    dot={false}
                  />
                  <Area
                    type="monotone"
                    dataKey="alunos"
                    name="Novos alunos"
                    stroke="hsl(var(--primary))"
                    strokeWidth={2.5}
                    fill="url(#axFlow)"
                    dot={false}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="rounded-3xl border border-border bg-card p-7">
            <h2 className="text-lg font-bold text-foreground">Distribuição de acessos</h2>
            <div className="relative mx-auto mt-6 h-[200px] w-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={distribution}
                    dataKey="value"
                    innerRadius={68}
                    outerRadius={92}
                    paddingAngle={3}
                    stroke="none"
                  >
                    {distribution.map((d) => (
                      <Cell key={d.name} fill={d.color} />
                    ))}
                  </Pie>
                  <Tooltip content={<ChartTooltip />} />
                </PieChart>
              </ResponsiveContainer>
              <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground">
                  Total
                </span>
                <span className="text-3xl font-black text-foreground">
                  {nf.format(distributionTotal)}
                </span>
              </div>
            </div>

            <ul className="mt-6 space-y-3">
              {distribution.map((d) => (
                <li key={d.name} className="flex items-center gap-3 text-sm">
                  <span className="h-2 w-2 rounded-full" style={{ background: d.color }} />
                  <span className="text-muted-foreground">{d.name}</span>
                  <span className="ml-auto font-bold text-foreground">{nf.format(d.value)}</span>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* 5. Simulação + 6. Atividade recente */}
        <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="min-w-0 rounded-3xl border border-border bg-card p-5 sm:p-7">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-foreground">Meta de onboarding</h2>
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary text-primary">
                <Sparkles className="h-4 w-4" />
              </span>
            </div>

            <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-primary/15 text-primary">
                  <Users className="h-5 w-5" />
                </span>
                <div>
                  <p className="font-semibold text-foreground">Turma Axionfly</p>
                  <p className="text-xs text-muted-foreground">
                    {assistiram} de {totalAlunos || 0} alunos no fluxo completo
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-3xl font-black text-foreground">{conclusao}%</p>
                <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-muted-foreground">
                  Conclusão
                </p>
              </div>
            </div>

            <div className="mt-6 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
              <div
                className="h-full rounded-full bg-primary transition-all duration-1000 ease-out"
                style={{ width: barReady ? `${Math.min(conclusao, 100)}%` : "0%" }}
              />
            </div>
          </div>

          <div className="min-w-0 rounded-3xl border border-border bg-card p-5 sm:p-7">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-foreground">Atividade recente</h2>
              <button
                onClick={() => navigate("/admin/aulas")}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-colors hover:text-foreground"
                aria-label="Ver todas as aulas"
              >
                <ArrowUpRight className="h-4 w-4" />
              </button>
            </div>

            <ul className="mt-4 divide-y divide-border">
              {lessons.length === 0 && (
                <li className="py-6 text-sm text-muted-foreground">Nenhuma atividade registrada.</li>
              )}
              {lessons.map((lesson) => (
                <li
                  key={lesson.id}
                  className="flex items-center gap-3 rounded-xl px-2 py-3 transition-colors hover:bg-secondary/60"
                >
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-secondary text-primary">
                    <PlayCircle className="h-4 w-4" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-foreground">{lesson.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {lesson.created_at
                        ? new Date(lesson.created_at).toLocaleDateString("pt-BR")
                        : "Sem data"}{" "}
                      · Aula publicada
                    </p>
                  </div>
                  <span className="ml-auto text-sm font-bold text-foreground">Ativa</span>
                </li>
              ))}
            </ul>
          </div>
        </section>
      </div>
    </div>
  );
};

export default AdminDashboardOverview;
