import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BookOpen, LayoutDashboard, Users, LogOut, Clock, Check, Trash2, KeyRound, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { isAdminUser } from "@/lib/admin-access";
import { useAsyncFeedback } from "@/hooks/use-async-feedback";
import { LoadError } from "@/components/live/LoadError";
import { AdminMobileNav } from "@/components/live/AdminMobileNav";

type AccessRequest = {
  id: string;
  email: string;
  released_at: string;
  first_attempt_at: string;
  created_at: string;
};

const AdminAccessRequests = () => {
  const navigate = useNavigate();
  const { run, error: requestError } = useAsyncFeedback();
  const { toast } = useToast();
  const [requests, setRequests] = useState<AccessRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [now, setNow] = useState(Date.now());
  const [search, setSearch] = useState("");

  useEffect(() => {
    const check = async () => {
      await run(async () => {
      try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return navigate("/login?admin=1");
      const admin = await isAdminUser(session.user.id);
      if (!admin) {
        await supabase.auth.signOut();
        return navigate("/login?admin=1");
      }
      await fetchRequests();
      } finally { setLoading(false); }
      }, "Não foi possível concluir a solicitação. Tente novamente.");
    };
    check();
    const t = setInterval(() => setNow(Date.now()), 30000);
    return () => clearInterval(t);
  }, [navigate]);

  const fetchRequests = async () => {
      await run(async () => {
      try {
    setLoading(true);
    const { data, error } = await supabase
      .from("access_requests")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) {
      throw error;
    } else {
      setRequests((data as AccessRequest[]) || []);
    }
    setLoading(false);
      } finally { setLoading(false); }
      }, "Não foi possível concluir a solicitação. Tente novamente.");
  };

  const releaseNow = async (id: string) => {
      await run(async () => {
      try {
    const iso = new Date(Date.now() - 60 * 1000).toISOString();
    const { error } = await supabase
      .from("access_requests")
      .update({ released_at: iso })
      .eq("id", id);
    if (error) {
      toast({ title: "Erro", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Acesso liberado" });
      await fetchRequests();
    }
      } finally { setLoading(false); }
      }, "Não foi possível concluir a solicitação. Tente novamente.");
  };

  const removeRequest = async (id: string) => {
      await run(async () => {
      try {
    const { error } = await supabase.from("access_requests").delete().eq("id", id);
    if (error) {
      toast({ title: "Erro", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Removido" });
      await fetchRequests();
    }
      } finally { setLoading(false); }
      }, "Não foi possível concluir a solicitação. Tente novamente.");
  };

  const formatRemaining = (releasedAt: string) => {
    const diffMs = new Date(releasedAt).getTime() - now;
    if (diffMs <= 0) return { text: "Liberado", released: true };
    const totalMin = Math.ceil(diffMs / 60000);
    if (totalMin >= 60) {
      const h = Math.floor(totalMin / 60);
      const m = totalMin % 60;
      return { text: `${h}h ${m}min restantes`, released: false };
    }
    return { text: `${totalMin} min restantes`, released: false };
  };

  const filtered = requests.filter(r => r.email.toLowerCase().includes(search.toLowerCase()));
  const pending = filtered.filter(r => new Date(r.released_at).getTime() > now);
  const released = filtered.filter(r => new Date(r.released_at).getTime() <= now);

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="hidden w-64 shrink-0 border-r border-border bg-card p-6 md:flex flex-col">
        <div className="mb-10">
          <h1 className="text-xl font-black tracking-tighter text-foreground">PROJETO</h1>
          <p className="text-[10px] font-bold text-primary uppercase tracking-widest mt-1">Painel Admin</p>
        </div>
        <nav className="flex-1 space-y-2">
          <Button variant="ghost" onClick={() => navigate("/admin/modulos")} className="w-full justify-start gap-3 text-muted-foreground hover:bg-white/5">
            <BookOpen className="h-5 w-5" /> Módulos
          </Button>
          <Button variant="ghost" onClick={() => navigate("/admin/aulas")} className="w-full justify-start gap-3 text-muted-foreground hover:bg-white/5">
            <LayoutDashboard className="h-5 w-5" /> Aulas
          </Button>
          <Button variant="ghost" onClick={() => navigate("/admin/alunos")} className="w-full justify-start gap-3 text-muted-foreground hover:bg-white/5">
            <Users className="h-5 w-5" /> Alunos
          </Button>
          <Button variant="ghost" className="w-full justify-start gap-3 bg-primary/10 text-primary">
            <KeyRound className="h-5 w-5" /> Liberações
          </Button>
        </nav>
        <Button variant="ghost" onClick={() => navigate("/")} className="mt-auto justify-start gap-3 text-muted-foreground">
          <LogOut className="h-5 w-5" /> Sair do Admin
        </Button>
      </aside>

      <main className="min-w-0 flex-1 p-4 sm:p-6 lg:p-10">
        <AdminMobileNav />
        {requestError && <LoadError message={requestError} retry={() => window.location.reload()} />}
        <header className="mb-8 flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
          <div>
            <h2 className="text-3xl font-bold">Liberações de Acesso</h2>
            <p className="text-sm text-muted-foreground mt-1">Consulte os acessos registrados e suas liberações.</p>
          </div>
          <div className="flex gap-2">
            <Input placeholder="Buscar por e-mail..." value={search} onChange={e => setSearch(e.target.value)} className="w-64 bg-card" />
            <Button variant="outline" size="icon" onClick={fetchRequests}><RefreshCw className="h-4 w-4" /></Button>
          </div>
        </header>

        <div className="grid min-w-0 grid-cols-1 gap-8">
          <section>
            <h3 className="mb-3 text-sm font-bold uppercase tracking-widest text-primary flex items-center gap-2">
              <Clock className="h-4 w-4" /> Aguardando ({pending.length})
            </h3>
            <div className="rounded-xl border border-border bg-card overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-white/5 text-xs font-bold uppercase tracking-widest text-muted-foreground">
                  <tr>
                    <th className="px-6 py-4">E-mail</th>
                    <th className="px-6 py-4">Primeira tentativa</th>
                    <th className="px-6 py-4">Tempo restante</th>
                    <th className="px-6 py-4 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {pending.map(r => {
                    const status = formatRemaining(r.released_at);
                    return (
                      <tr key={r.id} className="hover:bg-white/[0.02]">
                        <td className="px-6 py-4 font-medium">{r.email}</td>
                        <td className="px-6 py-4 text-sm text-muted-foreground">
                          {new Date(r.first_attempt_at).toLocaleString("pt-BR")}
                        </td>
                        <td className="px-6 py-4 text-sm font-semibold text-amber-400">{status.text}</td>
                        <td className="px-6 py-4 text-right flex justify-end gap-2">
                          <Button size="sm" onClick={() => releaseNow(r.id)} className="bg-primary text-primary-foreground gap-2">
                            <Check className="h-4 w-4" /> Liberar agora
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => removeRequest(r.id)} className="text-muted-foreground hover:text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {pending.length === 0 && !loading && (
                <div className="p-8 text-center text-muted-foreground text-sm">Ninguém aguardando no momento.</div>
              )}
            </div>
          </section>

          <section>
            <h3 className="mb-3 text-sm font-bold uppercase tracking-widest text-emerald-400 flex items-center gap-2">
              <Check className="h-4 w-4" /> Já liberados ({released.length})
            </h3>
            <div className="rounded-xl border border-border bg-card overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-white/5 text-xs font-bold uppercase tracking-widest text-muted-foreground">
                  <tr>
                    <th className="px-6 py-4">E-mail</th>
                    <th className="px-6 py-4">Liberado em</th>
                    <th className="px-6 py-4 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {released.map(r => (
                    <tr key={r.id} className="hover:bg-white/[0.02]">
                      <td className="px-6 py-4 font-medium">{r.email}</td>
                      <td className="px-6 py-4 text-sm text-muted-foreground">
                        {new Date(r.released_at).toLocaleString("pt-BR")}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <Button variant="ghost" size="icon" onClick={() => removeRequest(r.id)} className="text-muted-foreground hover:text-destructive">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {released.length === 0 && !loading && (
                <div className="p-8 text-center text-muted-foreground text-sm">Nenhum registro liberado ainda.</div>
              )}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
};

export default AdminAccessRequests;
