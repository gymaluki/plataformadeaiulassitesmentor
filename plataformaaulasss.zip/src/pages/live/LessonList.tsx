import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Play, CheckCircle2, Clock, Info } from "lucide-react";
import { Header } from "@/components/live/Header";
import { supabase } from "@/integrations/supabase/client";
import { ensureMemberSession } from "@/lib/session";
import { Button } from "@/components/ui/button";
import { canAccessModule, getCourseSchedule, type ScheduleModule } from "@/lib/course-schedule";
import { isAdminUser } from "@/lib/admin-access";
import { useToast } from "@/hooks/use-toast";
import { LoadError } from "@/components/live/LoadError";

interface Lesson {
  id: string;
  title: string;
  duration_seconds: number;
  completed: boolean;
}

const LessonList = () => {
  const { moduleId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [moduleTitle, setModuleTitle] = useState("");
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [loadAttempt, setLoadAttempt] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setLoadError(null);
      setLessons([]);
      try {
      const ok = await ensureMemberSession();
      if (!ok) {
        navigate("/login");
        return;
      }
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/login");
        return;
      }

      const { data: moduleData, error: moduleError } = await supabase
        .from("app_modules")
        .select("id, title, order_index, is_private, release_day")
        .eq("id", moduleId)
        .single();
      if (moduleError) throw moduleError;
      
      if (moduleData) setModuleTitle(moduleData.title);

      const [{ data: modulesData, error: modulesError }, schedule, isAdmin] = await Promise.all([
        supabase
          .from("app_modules")
          .select("id, title, order_index, is_private, release_day")
          .order("order_index", { ascending: true }),
        getCourseSchedule(),
        isAdminUser(session.user.id),
      ]);
      if (modulesError) throw modulesError;

      if (!canAccessModule(moduleData as ScheduleModule | null, (modulesData || []) as ScheduleModule[], schedule.unlocked_days, isAdmin)) {
        navigate("/", { replace: true });
        return;
      }

      const { data: lessonsData, error: lessonsError } = await supabase
        .from("app_lessons")
        .select("id, title, duration_seconds")
        .eq("module_id", moduleId)
        .eq("status", "published")
        .order("order_index", { ascending: true });

      if (lessonsError) throw lessonsError;

      if (lessonsData) {
        const { data: progressData, error: progressError } = await supabase
          .from("app_progress")
          .select("lesson_id")
          .eq("user_id", session.user.id)
          .eq("completed", true);
        if (progressError) throw progressError;

        const completedIds = new Set(progressData?.map(p => p.lesson_id));

        setLessons(
          lessonsData.map(l => ({
            ...l,
            completed: completedIds.has(l.id)
          }))
        );
      }
      } catch (error) {
        console.error("[lessons] loading failed", error);
        toast({ title: "Não foi possível carregar as aulas", description: "Tente abrir o módulo novamente.", variant: "destructive" });
        setLoadError("Não foi possível carregar as aulas e seu progresso. Tente novamente.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [moduleId, navigate, loadAttempt]);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    return `${mins} min`;
  };

  return (
    <div className="min-h-screen bg-spotlight text-foreground relative overflow-hidden">
      <div className="absolute inset-0 bg-noise pointer-events-none" />
      <div className="absolute inset-0 bg-grid opacity-30 pointer-events-none" />
      <div className="relative z-10">
        <Header />
        <main className="mx-auto max-w-3xl px-6 py-12">
          <Link to="/" className="mb-8 inline-flex items-center gap-2 text-sm font-bold text-muted-foreground hover:text-primary transition-colors">
            <ArrowLeft className="h-4 w-4" />
            Voltar
          </Link>

          <header className="mb-6 animate-fade-up">
            <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-primary/80">Módulo</span>
            <h1 className="mt-2 text-4xl font-bold tracking-tight text-gradient">{moduleTitle || "Carregando..."}</h1>
          </header>

          <div className="mb-8 flex items-start gap-3 rounded-xl border border-primary/20 bg-primary/5 backdrop-blur p-4 animate-fade-up">
            <Info className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
            <p className="text-sm leading-relaxed text-muted-foreground">
              Não há ordem obrigatória para assistir as aulas. Olhe os títulos e comece pela que fizer mais sentido para a sua necessidade.
            </p>
          </div>

          {loadError ? <LoadError message={loadError} retry={() => setLoadAttempt(value => value + 1)} /> : loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-20 animate-pulse rounded-xl bg-card border border-border" />
              ))}
            </div>
          ) : (
            <div className="space-y-3">
              {lessons.map((lesson, idx) => (
                <Link
                  key={lesson.id}
                  to={`/aula/${lesson.id}`}
                  style={{ animationDelay: `${idx * 50}ms` }}
                  className="group relative flex items-center gap-4 overflow-hidden rounded-xl border border-border bg-card/60 backdrop-blur p-4 transition-all duration-300 hover:border-primary/60 hover:-translate-y-0.5 hover:shadow-glow animate-fade-up"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/0 to-primary/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                  <div className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-sm font-bold text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                    {lesson.completed ? <CheckCircle2 className="h-5 w-5" /> : String(idx + 1).padStart(2, '0')}
                  </div>

                  <div className="relative flex-1 min-w-0">
                    <h3 className="font-bold truncate group-hover:text-primary transition-colors">{lesson.title}</h3>
                    <div className="mt-1 flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {formatDuration(lesson.duration_seconds)}
                      </span>
                      {lesson.completed && <span className="text-primary font-bold">Concluída</span>}
                    </div>
                  </div>

                  <div className="relative flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary opacity-0 -translate-x-2 transition-all duration-300 group-hover:opacity-100 group-hover:translate-x-0">
                    <Play className="h-4 w-4 fill-current" />
                  </div>
                </Link>
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default LessonList;
