import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Mail, Lock, Sparkles, ShieldCheck, PlayCircle, Eye, EyeOff, RefreshCw } from "lucide-react";
import { isAdminUser } from "@/lib/admin-access";
import { createAccessSession, ensureMemberSession } from "@/lib/session";

const Login = () => {
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [waitNotice, setWaitNotice] = useState<string | null>(null);
  const [backendError, setBackendError] = useState<string | null>(null);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session) {
        // Usa a lógica robusta de verificação de sessão em vez de duplicar aqui.
        const isValid = await ensureMemberSession();
        if (!mounted) return;

        if (isValid) {
          const admin = await isAdminUser(session.user.id);
          navigate(admin ? "/admin" : "/", { replace: true });
          return;
        }
        
        // Se a sessão existe mas não é válida (ex: perfil não encontrado após retries), limpa.
        await supabase.auth.signOut({ scope: "local" });
      }
      
      } catch {
        if (mounted) setBackendError("Não foi possível verificar seu acesso salvo. Tente entrar novamente.");
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, [navigate]);

  const handleLogin = async () => {
    const normalizedEmail = email.trim().toLowerCase();
    const normalizedPassword = password.trim();

    if (submitting || !normalizedEmail || !normalizedPassword) return;
    setSubmitting(true);
    setWaitNotice(null);
    setBackendError(null);

    try {
      const access = await createAccessSession(normalizedEmail, normalizedPassword);
      toast({ title: access.role === "admin" ? "Administrador conectado" : "Acesso liberado" });
      navigate(access.role === "admin" ? "/admin" : "/", { replace: true });
    } catch (error: any) {
      const msg = error?.message || "Confira o Gmail e a senha da plataforma.";

      if (msg.toLowerCase().includes("backend") || msg.toLowerCase().includes("manutenção") || msg.toLowerCase().includes("sessão segura")) {
        setBackendError(msg);
      } else if (msg.toLowerCase().includes("9 horas") || msg.toLowerCase().includes("analisando")) {
        setWaitNotice(msg);
      } else {
        toast({
          title: "Não foi possível entrar",
          description: msg,
          variant: "destructive",
        });
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleReload = () => {
    window.location.reload();
  };

  const handleSignOut = async () => {
    try {
      const { error } = await supabase.auth.signOut({ scope: "local" });
      if (error) throw error;
      setLoading(false);
    } catch {
      setBackendError("Não foi possível limpar o acesso salvo. Tente novamente.");
    }
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-background text-foreground">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -top-40 -left-32 h-[520px] w-[520px] animate-pulse rounded-full bg-primary/30 blur-[150px]" style={{ animationDuration: "6s" }} />
        <div className="absolute top-1/3 -right-32 h-[560px] w-[560px] animate-pulse rounded-full bg-accent/25 blur-[170px]" style={{ animationDuration: "8s" }} />
        <div className="absolute bottom-[-220px] left-1/3 h-[440px] w-[440px] animate-pulse rounded-full bg-primary-glow/25 blur-[150px]" style={{ animationDuration: "7s" }} />

        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Cpath d='M 48 0 L 0 0 0 48' fill='none' stroke='hsl(270 80% 70% / 0.12)' stroke-width='1'/%3E%3C/svg%3E")`,
            backgroundSize: "48px 48px",
            maskImage: "radial-gradient(ellipse at 50% 0%, black 20%, transparent 70%)",
            WebkitMaskImage: "radial-gradient(ellipse at 50% 0%, black 20%, transparent 70%)",
          }}
        />
      </div>

      <div className="mx-auto grid min-h-screen w-full max-w-6xl grid-cols-1 lg:grid-cols-[1.05fr_1fr]">
        <aside className="relative hidden flex-col justify-between p-12 lg:flex">
          <div className="flex items-center gap-2.5 text-sm font-semibold tracking-[0.18em] text-muted-foreground">
            <span
              className="inline-flex h-9 w-9 items-center justify-center rounded-xl text-primary-foreground"
              style={{ background: "var(--hero)", boxShadow: "var(--shadow-glow)" }}
            >
              <PlayCircle className="h-4 w-4" />
            </span>
            PROJETO
          </div>

          <div className="space-y-9">
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3.5 py-1.5 text-xs font-medium text-primary backdrop-blur">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
              </span>
              Mentoria ao vivo, acesso individual
            </div>
            <h1 className="text-[3.5rem] font-extrabold leading-[1.02] tracking-[-0.035em]">
              Sua jornada para o{" "}
              <span
                className="bg-clip-text text-transparent"
                style={{ backgroundImage: "var(--hero)" }}
              >
                próximo nível
              </span>{" "}
              começa aqui.
            </h1>
            <p className="max-w-md text-[15px] leading-relaxed text-muted-foreground">
              Conteúdo selecionado a dedo, módulos liberados conforme o seu progresso e
              acompanhamento próximo para você sair do zero ao avançado de verdade.
            </p>

            <ul className="space-y-3.5 text-[14px] text-foreground/80">
              {[
                "Cronograma personalizado para cada aluno",
                "Módulos progressivos sempre atualizados",
                "Suporte direto com o mentor responsável",
              ].map((item) => (
                <li key={item} className="flex items-center gap-3">
                  <span className="inline-flex h-6 w-6 items-center justify-center rounded-full border border-primary/30 bg-primary/10 text-primary">
                    <ShieldCheck className="h-3.5 w-3.5" />
                  </span>
                  {item}
                </li>
              ))}
            </ul>
          </div>

          <p className="text-xs text-muted-foreground/60">
            © {new Date().getFullYear()} Projeto · Todos os direitos reservados
          </p>
        </aside>

        <main className="flex items-center justify-center p-6 sm:p-10">
          <div className="w-full max-w-md">
            <div className="mb-8 lg:hidden">
              <div className="flex items-center gap-2 text-sm font-semibold tracking-[0.18em] text-muted-foreground">
                <span
                  className="inline-flex h-9 w-9 items-center justify-center rounded-xl text-primary-foreground"
                  style={{ background: "var(--hero)" }}
                >
                  <PlayCircle className="h-4 w-4" />
                </span>
                PROJETO
              </div>
            </div>

            <div
              className="relative rounded-[1.25rem] p-[1px]"
              style={{ background: "linear-gradient(140deg, hsl(var(--primary) / 0.6), hsl(var(--accent) / 0.15) 45%, hsl(var(--primary-glow) / 0.55))" }}
            >
            <div
              className="relative rounded-[1.18rem] border border-border/40 bg-card/85 p-8 backdrop-blur-2xl"
              style={{ boxShadow: "var(--shadow-elevated)" }}
            >
              <div
                className="pointer-events-none absolute inset-x-0 -top-px mx-auto h-px w-3/4"
                style={{ background: "linear-gradient(90deg, transparent, hsl(var(--primary) / 0.8), transparent)" }}
              />

              <div className="mb-6 space-y-1.5">
                <h2 className="text-2xl font-bold tracking-tight">Entrar na plataforma</h2>
                <p className="text-sm text-muted-foreground">
                  Use o seu Gmail cadastrado e a senha da plataforma. Novos alunos usam a senha <span className="font-semibold text-foreground">projeto</span>.
                </p>
              </div>

              {loading ? (
                <div className="flex items-center gap-2 py-10 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin text-primary" /> Verificando sessão...
                </div>
              ) : waitNotice ? (
                <div className="space-y-5">
                  <div className="rounded-xl border border-primary/30 bg-primary/10 p-5">
                    <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-primary">
                      <Sparkles className="h-4 w-4" />
                      Estamos preparando o seu acesso
                    </div>
                    <p className="text-sm leading-relaxed text-foreground/90">{waitNotice}</p>
                  </div>
                  <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-center text-xs leading-relaxed text-amber-200">
                    Já passou o horário e ainda não entrou? Atualize a página (F5 no computador ou puxe a tela para baixo no celular) que o acesso é liberado.
                  </div>
                </div>
              ) : (
                <div className="space-y-5">
                  {backendError && (
                    <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-4 text-sm leading-relaxed text-foreground/90">
                      <div className="mb-1 flex items-center gap-2 font-semibold text-destructive">
                        <RefreshCw className="h-4 w-4" />
                        Problema temporário no servidor
                      </div>
                      <p className="mb-3">{backendError}</p>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={handleReload}
                        className="w-full border-destructive/30 hover:bg-destructive/20"
                      >
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Atualizar página e tentar de novo
                      </Button>
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                      Gmail
                    </Label>
                    <div className="relative">
                      <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        id="email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="seugmail@gmail.com"
                        autoComplete="email"
                        className="h-11 pl-10"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                      Senha da plataforma
                    </Label>
                    <div className="relative">
                      <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                        placeholder="••••••••••••"
                        autoComplete="current-password"
                        className="h-11 px-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword((v) => !v)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground transition hover:text-foreground"
                        aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  <Button
                    onClick={handleLogin}
                    disabled={submitting || !email.trim() || !password.trim()}
                    className="group relative h-11 w-full overflow-hidden font-semibold text-primary-foreground"
                    style={{ background: "var(--hero)", boxShadow: "var(--shadow-glow)" }}
                  >
                    {submitting ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <span className="flex items-center gap-2">
                        Entrar na plataforma
                        <span className="transition-transform group-hover:translate-x-0.5">→</span>
                      </span>
                    )}
                  </Button>

                  <div className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground/80">
                    <ShieldCheck className="h-3.5 w-3.5 text-primary/70" />
                    Acesso protegido e individual
                  </div>

                  <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-center text-xs leading-relaxed text-amber-200">
                    Está com dificuldade para entrar? Atualize a página (aperte F5 no computador ou puxe a tela para baixo no celular) e tente novamente. Isso resolve na maioria dos casos.
                  </div>

                  <button
                    onClick={handleSignOut}
                    className="block w-full text-center text-xs text-muted-foreground/60 transition hover:text-muted-foreground"
                  >
                    Limpar acesso salvo neste dispositivo
                  </button>
                </div>
              )}
            </div>
            </div>

            <p className="mt-6 text-center text-xs text-muted-foreground/70">
              Primeiro acesso? O sistema analisa o seu Gmail e libera as videoaulas certas para o seu perfil.
            </p>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Login;
