import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Lock,
  CheckCircle2,
  Play,
  Target,
  LayoutTemplate,
  Instagram,
  MessageSquare,
  TrendingUp,
  Rocket,
  ClipboardCheck,
  ChevronRight,
  Puzzle,
  Monitor,
  Smartphone,
  Unlock,
} from "lucide-react";
import { Header } from "@/components/live/Header";
import { WelcomeVideoGate } from "@/components/live/WelcomeVideoGate";
import { supabase } from "@/integrations/supabase/client";
import { ensureMemberSession } from "@/lib/session";
import { getCourseSchedule, isExtensionModule } from "@/lib/course-schedule";
import { isAdminUser } from "@/lib/admin-access";
import { LoadError } from "@/components/live/LoadError";

interface ModuleRow {
  id: string;
  title: string;
  order_index: number;
  lesson_count: number;
  completed_count: number;
  is_private: boolean;
  release_day: number;
}

type PhaseKey = "fundacao" | "preparacao" | "acao";

interface DayMeta {
  day: number;
  shortTitle: string;
  description: string;
  icon: any;
  phase: PhaseKey;
}

const DAY_META: DayMeta[] = [
  {
    day: 1,
    shortTitle: "Mindset e visão geral do negócio",
    description:
      "Entenda como o mercado de criação de sites funciona, as oportunidades, o nicho ideal e como se posicionar.",
    icon: Target,
    phase: "fundacao",
  },
  {
    day: 2,
    shortTitle: "Criação do site modelo",
    description:
      "Aprenda a construir um site funcional e com boa aparência. Estruturas, páginas essenciais e ferramentas usadas.",
    icon: LayoutTemplate,
    phase: "fundacao",
  },
  {
    day: 3,
    shortTitle: "Instagram profissional",
    description:
      "Crie e configure o perfil, identidade visual, bio, primeiros posts e use o Instagram como ferramenta de captação.",
    icon: Instagram,
    phase: "fundacao",
  },
  {
    day: 4,
    shortTitle: "Técnica de abordagem",
    description:
      "Estude os scripts de conversa, como identificar clientes em potencial e o que falar no primeiro contato.",
    icon: MessageSquare,
    phase: "preparacao",
  },
  {
    day: 5,
    shortTitle: "Estratégia de vendas e objeções",
    description:
      'Como apresentar o serviço, lidar com "não tenho dinheiro", "vou pensar", "já tenho" e fechar com segurança.',
    icon: TrendingUp,
    phase: "preparacao",
  },
  {
    day: 6,
    shortTitle: "Primeiras abordagens reais",
    description:
      "Aplique tudo na prática. Entre em contato com os primeiros potenciais clientes usando os scripts aprendidos.",
    icon: Rocket,
    phase: "acao",
  },
  {
    day: 7,
    shortTitle: "Revisão, seguimento e próximos passos",
    description:
      "Analise as abordagens, ajuste o que não funcionou, faça follow-up e defina a sua rotina de vendas.",
    icon: ClipboardCheck,
    phase: "acao",
  },
];

const PHASES: Record<
  PhaseKey,
  { label: string; range: string; color: string; ring: string; dot: string; text: string; bg: string }
> = {
  fundacao: {
    label: "Fase 1 · Fundação",
    range: "Dias 1 a 3",
    color: "violet",
    ring: "ring-primary/30",
    dot: "bg-primary",
    text: "text-primary",
    bg: "bg-primary/10 border-primary/30",
  },
  preparacao: {
    label: "Fase 2 · Preparação",
    range: "Dias 4 e 5",
    color: "violet",
    ring: "ring-accent/30",
    dot: "bg-accent",
    text: "text-accent",
    bg: "bg-accent/10 border-accent/30",
  },
  acao: {
    label: "Fase 3 · Ação real",
    range: "Dias 6 e 7",
    color: "violet",
    ring: "ring-primary-glow/30",
    dot: "bg-[hsl(var(--primary-glow))]",
    text: "text-[hsl(var(--primary-glow))]",
    bg: "bg-[hsl(var(--primary-glow))]/10 border-[hsl(var(--primary-glow))]/30",
  },
};


const ModuleList = () => {
  const navigate = useNavigate();
  const [modules, setModules] = useState<ModuleRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [unlockedDays, setUnlockedDays] = useState(1);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [loadAttempt, setLoadAttempt] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setLoadError(null);
      try {
      const ok = await ensureMemberSession();
      if (!ok) {
        navigate("/login");
        return;
      }
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/login");
        return;
      }

      const [schedule, admin] = await Promise.all([
        getCourseSchedule(),
        isAdminUser(session.user.id),
      ]);
      setUnlockedDays(schedule.unlocked_days);
      setIsAdmin(admin);

      const { data: modulesData, error: modulesError } = await supabase
        .from("app_modules")
        .select("id, title, order_index, is_private, release_day")
        .order("order_index", { ascending: true });

      if (modulesError) throw modulesError;

      if (modulesData) {
        const rows: ModuleRow[] = [];
        for (const m of modulesData) {
          const { data: lessons, error: lessonsError } = await supabase
            .from("app_lessons")
            .select("id")
            .eq("module_id", m.id)
            .eq("status", "published");
          if (lessonsError) throw lessonsError;
          const lessonIds = (lessons || []).map((l) => l.id);
          let completed = 0;
          if (lessonIds.length > 0) {
            const { data: progress, error: progressError } = await supabase
              .from("app_progress")
              .select("lesson_id, completed")
              .eq("user_id", session.user.id)
              .in("lesson_id", lessonIds);
            if (progressError) throw progressError;
            completed = (progress || []).filter((p) => p.completed).length;
          }
          rows.push({
            id: m.id,
            title: m.title,
            order_index: m.order_index,
            lesson_count: lessonIds.length,
            completed_count: completed,
            is_private: Boolean(m.is_private),
            release_day: Math.max(1, Number(m.release_day ?? 1)),
          });
        }
        setModules(rows);
      }
      } catch (error) {
        console.error("[modules] loading failed", error);
        setLoadError("Não foi possível carregar seu cronograma e progresso. Tente novamente.");
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [navigate, loadAttempt]);

  const isComplementaryModule = (title: string) => /complementar/i.test(title);
  const extensionModules = modules.filter((m) => isExtensionModule(m.title) && !isComplementaryModule(m.title));
  const complementaryModules = modules.filter((m) => isComplementaryModule(m.title));
  const scheduleModules = modules
    .filter((m) => !isExtensionModule(m.title) && !isComplementaryModule(m.title))
    .sort((a, b) => a.order_index - b.order_index);

  // Mapeia os módulos restantes para os dias do cronograma (Dia 1 = primeiro módulo não-extensão, e assim por diante)
  const days = DAY_META.map((meta, i) => {
    const mod = scheduleModules.find((module) => module.release_day === meta.day);
    return { meta, mod };
  });
  const isUnlocked = (module?: ModuleRow, fallbackDay = 1): boolean => {
    if (!module) return false;
    if (isAdmin) return true;
    return !module.is_private && unlockedDays >= (module.release_day || fallbackDay);
  };


  const phasesOrder: PhaseKey[] = ["fundacao", "preparacao", "acao"];

  const totalLessons = modules.reduce((acc, m) => acc + m.lesson_count, 0);
  const totalCompleted = modules.reduce((acc, m) => acc + m.completed_count, 0);
  const overall = totalLessons > 0 ? Math.round((totalCompleted / totalLessons) * 100) : 0;

  return (
    <div className="min-h-screen bg-spotlight text-foreground relative overflow-hidden">
      <WelcomeVideoGate />
      <div className="absolute inset-0 bg-noise pointer-events-none" />
      <div className="absolute inset-0 bg-grid opacity-30 pointer-events-none" />
      <div className="relative z-10">
        <Header />
        <main className="mx-auto max-w-5xl px-4 sm:px-6 py-12 sm:py-16">
          {/* Cabeçalho */}
          <header className="mb-12 animate-fade-up">
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.2em] text-primary mb-5">
              <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
              Cronograma de 7 dias
            </span>
            <h1 className="text-4xl sm:text-6xl font-bold tracking-tight">
              <span className="text-gradient">Cronograma da Mentoria</span>
            </h1>
            <p className="mt-3 text-lg text-muted-foreground">
              Vendas de sites · do aprendizado à primeira abordagem real
            </p>

            {/* Barra de progresso geral */}
            <div className="mt-8 rounded-2xl border border-primary/20 bg-card/60 backdrop-blur-md p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold uppercase tracking-[0.2em] text-muted-foreground">
                  Seu progresso
                </span>
                <span className="text-sm font-bold text-primary tabular-nums">{overall}%</span>
              </div>
              <div className="h-2 rounded-full bg-white/5 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-primary via-primary-glow to-accent transition-all duration-700"
                  style={{ width: `${overall}%` }}
                />
              </div>
              <p className="mt-3 text-xs text-muted-foreground">
                {totalCompleted} de {totalLessons} aulas concluídas · novos dias liberam automaticamente à meia-noite
              </p>
            </div>
          </header>

          {loadError ? <LoadError message={loadError} retry={() => setLoadAttempt(value => value + 1)} /> : loading ? (
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-32 animate-pulse rounded-2xl bg-card border border-border" />
              ))}
            </div>
          ) : (
            <div className="space-y-12">
              {/* Aulas da extensão */}
              {extensionModules.length > 0 && (
                <section className="animate-fade-up">
                  <div className="flex items-center gap-3 mb-5 rounded-xl border border-primary/30 bg-primary/10 px-4 py-3">
                    <Unlock className="h-4 w-4 text-primary" />
                    <h2 className="text-sm font-bold uppercase tracking-[0.18em] text-primary">
                      Extensão
                    </h2>
                    <span className="ml-auto text-[11px] font-medium text-muted-foreground">
                      Computador e celular
                    </span>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    {extensionModules.map((mod) => {
                      const unlocked = isUnlocked(mod);
                      const progress =
                        mod.lesson_count > 0
                          ? (mod.completed_count / mod.lesson_count) * 100
                          : 0;
                      const completed =
                        mod.lesson_count > 0 && mod.completed_count >= mod.lesson_count;
                      const isMobile = /celular|mobile|android|ios|iphone/i.test(mod.title);
                      const Icon = isMobile ? Smartphone : Monitor;

                      return (
                        <Link
                          key={mod.id}
                          to={unlocked ? `/modulo/${mod.id}` : "#"}
                          onClick={(event) => !unlocked && event.preventDefault()}
                          className={`group relative flex items-stretch gap-4 rounded-2xl border border-primary/20 bg-card/80 backdrop-blur-xl p-5 transition-all duration-300 ${unlocked ? "hover:border-primary/60 hover:-translate-y-0.5 hover:shadow-glow" : "cursor-not-allowed opacity-50"}`}
                        >
                          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl border border-primary/30 bg-primary/10 text-primary">
                            <Icon className="h-6 w-6" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                              <span className="inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-[0.16em] border border-primary/30 bg-primary/10 text-primary">
                                <Puzzle className="h-3 w-3" />
                                Extensão
                              </span>
                              {completed && (
                                <span className="inline-flex items-center gap-1 rounded-full bg-primary/15 border border-primary/30 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-primary">
                                  <CheckCircle2 className="h-3 w-3" />
                                  Concluído
                                </span>
                              )}
                              {!unlocked && (
                                <span className="inline-flex items-center gap-1 rounded-full border border-border bg-muted/30 px-2 py-0.5 text-[10px] font-bold uppercase text-muted-foreground">
                                  <Lock className="h-3 w-3" /> {mod.is_private ? "Privado" : `Dia ${mod.release_day}`}
                                </span>
                              )}
                            </div>
                            <h3 className="text-base sm:text-lg font-bold leading-snug">
                              {mod.title}
                            </h3>
                            {mod.lesson_count > 0 && (
                              <div className="mt-3 space-y-1.5">
                                <div className="flex items-center justify-between text-[11px] font-medium text-muted-foreground">
                                  <span>
                                    {mod.completed_count} de {mod.lesson_count} aulas
                                  </span>
                                  <span className="text-primary font-bold tabular-nums">
                                    {Math.round(progress)}%
                                  </span>
                                </div>
                                <div className="h-1 rounded-full bg-white/5 overflow-hidden">
                                  <div
                                    className="h-full rounded-full bg-gradient-to-r from-primary to-accent transition-all duration-700"
                                    style={{ width: `${progress}%` }}
                                  />
                                </div>
                              </div>
                            )}
                          </div>
                          <div className="flex flex-col items-center justify-center">
                            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/15 text-primary border border-primary/30">
                              {unlocked ? <Play className="h-4 w-4 fill-current ml-0.5" /> : <Lock className="h-4 w-4" />}
                            </div>
                          </div>
                        </Link>
                      );
                    })}
                  </div>

                </section>
              )}

              {complementaryModules.length > 0 && (
                <section className="animate-fade-up">
                  <div className="mb-5 flex items-center gap-3 rounded-xl border border-primary/30 bg-primary/10 px-4 py-3">
                    <Puzzle className="h-4 w-4 text-primary" />
                    <h2 className="text-sm font-bold uppercase tracking-[0.18em] text-primary">Aulas complementares</h2>
                    <span className="ml-auto text-[11px] font-medium text-muted-foreground">Liberação no Dia 2</span>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    {complementaryModules.map((mod) => {
                      const unlocked = isUnlocked(mod, 2);
                      return (
                        <Link
                          key={mod.id}
                          to={unlocked ? `/modulo/${mod.id}` : "#"}
                          onClick={(event) => !unlocked && event.preventDefault()}
                          className={`flex items-center gap-4 rounded-2xl border bg-card/80 p-5 backdrop-blur-xl transition-all ${unlocked ? "border-primary/30 hover:border-primary/60 hover:shadow-glow" : "cursor-not-allowed border-border opacity-50"}`}
                        >
                          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-primary/30 bg-primary/10 text-primary">
                            {unlocked ? <Unlock className="h-5 w-5" /> : <Lock className="h-5 w-5" />}
                          </div>
                          <div className="min-w-0 flex-1">
                            <h3 className="font-bold">{mod.title}</h3>
                            <p className="mt-1 text-xs text-muted-foreground">
                              {mod.is_private ? "Conteúdo privado" : unlocked ? `${mod.lesson_count} aulas disponíveis` : `Libera no Dia ${mod.release_day}`}
                            </p>
                          </div>
                        </Link>
                      );
                    })}
                  </div>
                </section>
              )}


              {phasesOrder.map((phaseKey) => {
                const phase = PHASES[phaseKey];
                const phaseDays = days
                  .map((d, i) => ({ ...d, idx: i }))
                  .filter((d) => d.meta.phase === phaseKey);

                return (
                  <section key={phaseKey} className="animate-fade-up">
                    {/* Cabeçalho da fase */}
                    <div className={`flex items-center gap-3 mb-5 rounded-xl border ${phase.bg} px-4 py-3`}>
                      <span className={`h-2.5 w-2.5 rounded-full ${phase.dot}`} />
                      <h2 className={`text-sm font-bold uppercase tracking-[0.18em] ${phase.text}`}>
                        {phase.label}
                      </h2>
                      <span className="ml-auto text-[11px] font-medium text-muted-foreground">
                        {phase.range}
                      </span>
                    </div>

                    {/* Linha do tempo */}
                    <div className="relative pl-6 sm:pl-8">
                      {/* Linha vertical */}
                      <div className="absolute left-[11px] sm:left-[15px] top-2 bottom-2 w-px bg-gradient-to-b from-border via-border to-transparent" />

                      <div className="space-y-4">
                        {phaseDays.map(({ meta, mod, idx }) => {
                          const unlocked = isUnlocked(mod, meta.day);
                          const Icon = meta.icon;
                          const progress =
                            mod && mod.lesson_count > 0
                              ? (mod.completed_count / mod.lesson_count) * 100
                              : 0;
                          const completed =
                            mod && mod.lesson_count > 0 && mod.completed_count >= mod.lesson_count;

                          const cardInner = (
                            <div
                              className={`relative flex flex-col sm:flex-row items-stretch gap-4 rounded-2xl border bg-card/80 backdrop-blur-xl p-5 sm:p-6 transition-all duration-300 ${
                                unlocked
                                  ? "border-border hover:border-primary/60 hover:-translate-y-0.5 hover:shadow-glow cursor-pointer"
                                  : "border-border/50 opacity-60"
                              }`}
                            >
                              {/* Ícone */}
                              <div
                                className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-xl border ${
                                  unlocked
                                    ? `${phase.bg} ${phase.text}`
                                    : "border-border bg-muted/20 text-muted-foreground"
                                }`}
                              >
                                {unlocked ? <Icon className="h-6 w-6" /> : <Lock className="h-5 w-5" />}
                              </div>

                              {/* Conteúdo */}
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                                  <span
                                    className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-[0.16em] border ${phase.bg} ${phase.text}`}
                                  >
                                    Dia {meta.day}
                                  </span>
                                  {completed && (
                                    <span className="inline-flex items-center gap-1 rounded-full bg-primary/15 border border-primary/30 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-primary">
                                      <CheckCircle2 className="h-3 w-3" />
                                      Concluído
                                    </span>
                                  )}
                                  {!unlocked && (
                                    <span className="inline-flex items-center gap-1 rounded-full bg-muted/30 border border-border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                                      <Lock className="h-3 w-3" />
                                      Bloqueado
                                    </span>
                                  )}
                                </div>
                                <h3 className="text-lg sm:text-xl font-bold leading-snug">
                                  {meta.shortTitle}
                                </h3>
                                <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">
                                  {meta.description}
                                </p>

                                {/* Progresso */}
                                {unlocked && mod && mod.lesson_count > 0 && (
                                  <div className="mt-4 space-y-1.5">
                                    <div className="flex items-center justify-between text-[11px] font-medium text-muted-foreground">
                                      <span>
                                        {mod.completed_count} de {mod.lesson_count} aulas
                                      </span>
                                      <span className="text-primary font-bold tabular-nums">
                                        {Math.round(progress)}%
                                      </span>
                                    </div>
                                    <div className="h-1 rounded-full bg-white/5 overflow-hidden">
                                      <div
                                        className="h-full rounded-full bg-gradient-to-r from-primary to-accent transition-all duration-700"
                                        style={{ width: `${progress}%` }}
                                      />
                                    </div>
                                  </div>
                                )}

                                {!unlocked && (
                                  <p className="mt-3 text-xs text-muted-foreground italic">
                                     {mod?.is_private ? "Este conteúdo está privado no momento." : `Este conteúdo libera no Dia ${mod?.release_day ?? meta.day}.`}
                                  </p>
                                )}
                              </div>

                              {/* Ação */}
                              {unlocked && mod && (
                                <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center gap-2 sm:min-w-[110px]">
                                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/15 text-primary border border-primary/30">
                                    <Play className="h-4 w-4 fill-current ml-0.5" />
                                  </div>
                                  <span className="flex items-center gap-1 text-xs font-bold text-primary">
                                    Acessar
                                    <ChevronRight className="h-3.5 w-3.5" />
                                  </span>
                                </div>
                              )}
                            </div>
                          );

                          return (
                            <div key={meta.day} className="relative">
                              {/* Marcador na linha do tempo */}
                              <div
                                className={`absolute -left-6 sm:-left-8 top-6 flex h-6 w-6 sm:h-8 sm:w-8 items-center justify-center rounded-full border-2 text-[10px] sm:text-xs font-bold tabular-nums ${
                                  unlocked
                                    ? `${phase.dot} border-background text-white`
                                    : "bg-muted border-background text-muted-foreground"
                                }`}
                              >
                                {meta.day}
                              </div>

                              {unlocked && mod ? (
                                <Link to={`/modulo/${mod.id}`} className="block">
                                  {cardInner}
                                </Link>
                              ) : (
                                <div>{cardInner}</div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </section>
                );
              })}
            </div>
          )}

          {/* Legenda */}
          <div className="mt-12 rounded-2xl border border-border bg-card/60 backdrop-blur-md p-5">
            <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-muted-foreground mb-3">
              Como funciona
            </p>
            <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-primary" />
                Fundação
              </span>
              <span className="inline-flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-accent" />
                Preparação
              </span>
              <span className="inline-flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-[hsl(var(--primary-glow))]" />
                Ação real
              </span>

              <span className="inline-flex items-center gap-2 ml-auto">
                <Lock className="h-3.5 w-3.5" />
                Cada novo dia libera à meia-noite
              </span>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ModuleList;
