import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, CheckCircle2, ChevronLeft, ChevronRight, Check } from "lucide-react";
import { Header } from "@/components/live/Header";
import { supabase } from "@/integrations/supabase/client";
import { ensureMemberSession } from "@/lib/session";
import { Button } from "@/components/ui/button";
import ReactPlayer from "react-player";
import { Progress } from "@/components/ui/progress";
import { canAccessModule, getCourseSchedule, type ScheduleModule } from "@/lib/course-schedule";
import { isAdminUser } from "@/lib/admin-access";
import { useToast } from "@/hooks/use-toast";
import { LoadError } from "@/components/live/LoadError";

interface Lesson {
  id: string;
  title: string;
  video_url: string;
  description: string | null;
  module_id: string;
}

const Player = () => {
  const PlayerComp = ReactPlayer as any;

  const { lessonId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [lesson, setLesson] = useState<Lesson | null>(null);
  const [allLessons, setAllLessons] = useState<any[]>([]);
  const [completedIds, setCompletedIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [savingProgress, setSavingProgress] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [loadAttempt, setLoadAttempt] = useState(0);
  const [aspect, setAspect] = useState<"video" | "vertical" | "square">("video");

  const aspectClass =
    aspect === "vertical"
      ? "aspect-[9/16] max-w-sm mx-auto"
      : aspect === "square"
      ? "aspect-square max-w-2xl mx-auto"
      : "aspect-video";

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setLoadError(null);
      setLesson(null);
      try {
      const ok = await ensureMemberSession();
      if (!ok) {
        navigate("/login");
        return;
      }
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/login");
        return;
      }

      // Fetch current lesson
      const { data: lessonData, error: lessonError } = await supabase
        .from("app_lessons")
        .select("*")
        .eq("id", lessonId)
        .maybeSingle();
      if (lessonError) throw lessonError;

      if (!lessonData) {
        navigate("/", { replace: true });
        return;
      }

      if (lessonData) {
        const [{ data: moduleData, error: moduleError }, { data: modulesData, error: modulesError }, schedule, isAdmin] = await Promise.all([
          supabase
            .from("app_modules")
            .select("id, title, order_index, is_private, release_day")
            .eq("id", lessonData.module_id)
            .single(),
          supabase
            .from("app_modules")
            .select("id, title, order_index, is_private, release_day")
            .order("order_index", { ascending: true }),
          getCourseSchedule(),
          isAdminUser(session.user.id),
        ]);
        if (moduleError || modulesError) throw moduleError || modulesError;

        if (!canAccessModule(moduleData as ScheduleModule | null, (modulesData || []) as ScheduleModule[], schedule.unlocked_days, isAdmin)) {
          navigate("/", { replace: true });
          return;
        }

        setLesson(lessonData);

        // Fetch all lessons in same module
        const { data: lessonsData, error: lessonsError } = await supabase
          .from("app_lessons")
          .select("id, title, order_index")
        .eq("module_id", lessonData.module_id)
        .eq("status", "published")
        .order("order_index", { ascending: true });
        if (lessonsError) throw lessonsError;
        
        setAllLessons(lessonsData || []);

        // Fetch progress
        const { data: progressData, error: progressError } = await supabase
          .from("app_progress")
          .select("lesson_id")
          .eq("user_id", session.user.id)
          .eq("completed", true);
        if (progressError) throw progressError;
        
        setCompletedIds(new Set(progressData?.map(p => p.lesson_id)));
      }
      } catch (error) {
        console.error("[player] loading failed", error);
        toast({ title: "Não foi possível carregar a aula", description: "Tente abrir a aula novamente.", variant: "destructive" });
        setLoadError("Não foi possível carregar a aula e seu progresso. Tente novamente.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [lessonId, navigate, loadAttempt]);

  const toggleComplete = async () => {
    if (!lesson || savingProgress) return;
    setSavingProgress(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Entre novamente para salvar o progresso.");
      const isCompleted = completedIds.has(lesson.id);
      const { error } = isCompleted
        ? await supabase.from("app_progress").delete().eq("user_id", session.user.id).eq("lesson_id", lesson.id)
        : await supabase.from("app_progress").upsert({ user_id: session.user.id, lesson_id: lesson.id, completed: true }, { onConflict: "user_id,lesson_id" });
      if (error) throw error;
      if (isCompleted) {
      setCompletedIds(prev => {
        const next = new Set(prev);
        next.delete(lesson.id);
        return next;
      });
      } else {
        setCompletedIds(prev => new Set(prev).add(lesson.id));
      }
    } catch (error) {
      console.error("[player] progress save failed", error);
      toast({ title: "Não foi possível salvar seu progresso", description: "Tente novamente. A conclusão não foi alterada.", variant: "destructive" });
    } finally {
      setSavingProgress(false);
    }
  };

  const currentIndex = allLessons.findIndex(l => l.id === lessonId);
  const prevLesson = allLessons[currentIndex - 1];
  const nextLesson = allLessons[currentIndex + 1];

  const progress = allLessons.length > 0 ? (allLessons.filter(l => completedIds.has(l.id)).length / allLessons.length) * 100 : 0;

  if (loading) return <div className="min-h-screen bg-background flex items-center justify-center text-primary">Carregando...</div>;
  if (loadError) return <div className="min-h-screen bg-background text-foreground"><Header /><main className="mx-auto max-w-3xl px-6 py-8"><LoadError message={loadError} retry={() => setLoadAttempt(value => value + 1)} /></main></div>;
  if (!lesson) return <div className="min-h-screen bg-background flex items-center justify-center">Aula não encontrada.</div>;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main className="mx-auto max-w-7xl px-6 py-8">
        <Link to={`/modulo/${lesson.module_id}`} className="mb-6 flex items-center gap-2 text-sm font-bold text-muted-foreground hover:text-primary transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Voltar para o módulo
        </Link>

        <div className="grid gap-8 lg:grid-cols-[1fr_360px]">
          {/* Main Column */}
          <div className="space-y-6">
            <div className={`relative overflow-hidden rounded-2xl bg-black shadow-2xl ring-1 ring-white/5 ${aspectClass}`}>
              {(() => {
                const url = lesson.video_url || "";
                const isFile = url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".mov") || url.includes("/storage/");
                if (isFile) {
                  return (
                    <video
                      key={url}
                      src={url}
                      controls
                      controlsList="nodownload noremoteplayback"
                      disablePictureInPicture
                      playsInline
                      className="h-full w-full"
                    />
                  );
                }
                // YouTube ID extraction
                const ytMatch = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([A-Za-z0-9_-]{11})/);
                if (ytMatch) {
                  const id = ytMatch[1];
                  const src = `https://www.youtube-nocookie.com/embed/${id}?rel=0&modestbranding=1&showinfo=0&iv_load_policy=3&controls=1&disablekb=1&fs=1&playsinline=1`;
                  return (
                    <iframe
                      key={id}
                      src={src}
                      className="h-full w-full"
                      allow="accelerometer; autoplay; encrypted-media; picture-in-picture; fullscreen"
                      allowFullScreen
                      referrerPolicy="strict-origin-when-cross-origin"
                    />
                  );
                }
                return (
                  <PlayerComp
                    src={url}
                    url={url}
                    width="100%"
                    height="100%"
                    controls
                    playsinline
                    style={{ width: "100%", height: "100%" }}
                  />
                );
              })()}

            </div>

            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Formato:</span>
              <Button size="sm" variant={aspect === "video" ? "default" : "outline"} onClick={() => setAspect("video")} className={aspect === "video" ? "bg-primary text-primary-foreground" : "border-primary/20 text-primary"}>
                Deitado
              </Button>
              <Button size="sm" variant={aspect === "vertical" ? "default" : "outline"} onClick={() => setAspect("vertical")} className={aspect === "vertical" ? "bg-primary text-primary-foreground" : "border-primary/20 text-primary"}>
                Em pé
              </Button>
              <Button size="sm" variant={aspect === "square" ? "default" : "outline"} onClick={() => setAspect("square")} className={aspect === "square" ? "bg-primary text-primary-foreground" : "border-primary/20 text-primary"}>
                Quadrado
              </Button>
            </div>
            

            <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
              <h1 className="text-3xl font-bold tracking-tight">{lesson.title}</h1>
              <Button
                onClick={toggleComplete}
                disabled={savingProgress}
                variant={completedIds.has(lesson.id) ? "default" : "outline"}
                className={completedIds.has(lesson.id) ? "bg-primary text-primary-foreground" : "border-primary/20 text-primary"}
              >
                {completedIds.has(lesson.id) ? (
                  <><Check className="mr-2 h-4 w-4" /> Concluída</>
                ) : (
                  "Marcar como concluída"
                )}
              </Button>
            </div>

            <p className="text-lg leading-relaxed text-muted-foreground/90 whitespace-pre-wrap">
              {lesson.description || "Sem descrição adicional para esta aula."}
            </p>

            <div className="flex items-center justify-between border-t border-border pt-8">
              <Button
                variant="ghost"
                disabled={!prevLesson}
                onClick={() => navigate(`/aula/${prevLesson.id}`)}
                className="text-muted-foreground hover:text-foreground disabled:opacity-30"
              >
                <ChevronLeft className="mr-2 h-4 w-4" />
                Aula anterior
              </Button>
              <Button
                variant="ghost"
                disabled={!nextLesson}
                onClick={() => navigate(`/aula/${nextLesson.id}`)}
                className="text-muted-foreground hover:text-foreground disabled:opacity-30"
              >
                Próxima aula
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Sidebar */}
          <aside className="space-y-6">
            <div className="rounded-2xl border border-border bg-card p-6 shadow-soft">
              <h3 className="mb-4 text-xs font-bold uppercase tracking-widest text-muted-foreground">Progresso do Módulo</h3>
              <div className="mb-2 flex items-center justify-between text-sm font-bold">
                <span>{allLessons.filter(l => completedIds.has(l.id)).length} de {allLessons.length} aulas</span>
                <span className="text-primary">{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-1.5 bg-white/5" />
            </div>

            <div className="rounded-2xl border border-border bg-card overflow-hidden">
              <div className="p-4 border-b border-border bg-white/[0.02]">
                <h3 className="text-sm font-bold">Aulas do módulo</h3>
              </div>
              <div className="max-h-[500px] overflow-y-auto">
                {allLessons.map((l, idx) => (
                  <Link
                    key={l.id}
                    to={`/aula/${l.id}`}
                    className={`flex items-center gap-3 px-4 py-3 text-sm transition-all hover:bg-white/5 ${l.id === lessonId ? "bg-primary/10 text-primary font-bold border-l-2 border-primary" : "text-muted-foreground"}`}
                  >
                    <div className={`flex h-6 w-6 shrink-0 items-center justify-center rounded bg-white/5 text-[10px] ${l.id === lessonId ? "text-primary bg-primary/20" : ""}`}>
                      {String(idx + 1).padStart(2, '0')}
                    </div>
                    <span className="flex-1 truncate">{l.title}</span>
                    {completedIds.has(l.id) && (
                      <CheckCircle2 className="h-4 w-4 text-primary" />
                    )}
                  </Link>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </main>
    </div>
  );
};

export default Player;
