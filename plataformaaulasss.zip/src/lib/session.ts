import { createClient } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_PUBLISHABLE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

const loginClient = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    persistSession: false,
    autoRefreshToken: false,
    storage: {
      getItem: () => null,
      setItem: () => {},
      removeItem: () => {},
    },
  },
});

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export const ensureMemberSession = async (): Promise<boolean> => {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) return false;

  // Retry logic for profile fetch to handle eventual consistency/race conditions
  let lastError: unknown = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    const { data, error } = await supabase
      .from("profiles")
      .select("id, email, role")
      .eq("id", session.user.id)
      .maybeSingle();

    lastError = error;
    if (error) {
      console.error(`[session] profile check attempt ${attempt + 1} failed`, error);
    } else if (data?.id) {
      const hasMemberEmail = Boolean(data?.email?.trim());
      const isValid = Boolean(data.role === "admin" || (data.role === "student" && hasMemberEmail));
      if (isValid) return true;
    }

    if (attempt < 2) await sleep(500 * (attempt + 1));
  }

  if (lastError) throw new Error("Não foi possível verificar seu acesso salvo. Tente novamente.");
  return false;
};

export const createAccessSession = async (email: string, password: string) => {
  const normalizedEmail = email.trim().toLowerCase();
  const normalizedPassword = password.trim();

  if (!normalizedEmail || !normalizedPassword) {
    throw new Error("Preencha o Gmail e a senha da plataforma.");
  }

  // Limpa sessões anteriores apenas se necessário, evitando disparar eventos globais desnecessários.
  // Usamos scope local para não afetar outras abas se possível, mas aqui queremos garantir um novo login.
  await supabase.auth.signOut({ scope: "local" });
  await loginClient.auth.signOut({ scope: "local" });

  let anonymousData: any = null;
  let sessionError: Error | null = null;

  for (let attempt = 1; attempt <= 3; attempt++) {
    const result = await loginClient.auth.signInAnonymously();
    anonymousData = result.data;
    sessionError = result.error;

    if (!result.error && result.data.session?.access_token) break;

    if (attempt < 3) {
      await sleep(800 * attempt);
      await loginClient.auth.signOut({ scope: "local" });
    }
  }

  const accessToken = anonymousData?.session?.access_token;
  const refreshToken = anonymousData?.session?.refresh_token;

  if (sessionError || !accessToken) {
    console.error("[login] anonymous session failed", sessionError);
    throw new Error(
      "Não foi possível abrir uma sessão segura no momento. O backend pode estar em manutenção. Recarregue a página e tente de novo."
    );
  }

  let transferred = false;
  try {
    const { data, error } = await supabase.functions.invoke("member-login", {
      body: { email: normalizedEmail, password: normalizedPassword },
      headers: { Authorization: `Bearer ${accessToken}` },
    });

    if (error) {
      let serverMessage: string | undefined;
      try {
        const ctx: any = (error as any).context;
        if (ctx && typeof ctx.json === "function") {
          const body = await ctx.json();
          serverMessage = body?.error || body?.message;
        } else if (ctx && typeof ctx.text === "function") {
          const body = await ctx.text();
          try {
            const parsed = JSON.parse(body);
            serverMessage = parsed?.error || parsed?.message;
          } catch {
            serverMessage = body;
          }
        }
      } catch {
        // ignore
      }
      throw new Error(serverMessage || "Não foi possível entrar agora. Tente novamente em instantes.");
    }

    if (data?.error) throw new Error(data.error);
    if (data?.blocked) throw new Error(data.message);
    if (!data?.role) throw new Error("Resposta inesperada do servidor.");

    if (!refreshToken) throw new Error("Não foi possível salvar seu acesso. Tente entrar novamente.");
    {
      const { error: setSessionError } = await supabase.auth.setSession({
        access_token: accessToken,
        refresh_token: refreshToken,
      });

      if (setSessionError) {
        console.error("[login] setSession failed", setSessionError);
        throw new Error("Não foi possível salvar seu acesso. Tente entrar novamente.");
      } else {
        transferred = true;
        // Pequena pausa para garantir que o estado interno do Supabase e o Storage estejam sincronizados
        await sleep(100);
      }
    }

    return data as { email: string; role: "student" | "admin" };
  } finally {
    // Both clients now share the token; signing out here revokes the student's session.
    if (!transferred) await loginClient.auth.signOut({ scope: "local" });
  }
};
