import { describe, expect, it, vi } from "vitest";
vi.mock("@/integrations/supabase/client", () => ({ supabase: {} }));
import { canAccessModule } from "./course-schedule";

const complementary = { id: "complementary", title: "Aulas complementares", order_index: 5, release_day: 2, is_private: false };

describe("module availability", () => {
  it("releases complementary lessons on day 2, not day 1", () => {
    expect(canAccessModule(complementary, [], 1)).toBe(false);
    expect(canAccessModule(complementary, [], 2)).toBe(true);
  });
  it("keeps private modules unavailable to students even after their release day", () => {
    expect(canAccessModule({ ...complementary, is_private: true }, [], 99)).toBe(false);
  });
  it("allows administrators to review private and future content", () => {
    expect(canAccessModule({ ...complementary, is_private: true, release_day: 6 }, [], 1, true)).toBe(true);
  });
});