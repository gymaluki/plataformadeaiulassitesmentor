import { supabase } from "@/integrations/supabase/client";

export const ADMIN_EMAIL = "andreyhenriquev4@gmail.com";

export const isAdminUser = async (userId?: string | null) => {
  if (!userId) return false;

  const [{ data: roleRow, error: roleError }, { data: profileRow, error: profileError }] = await Promise.all([
    supabase
      .from("user_roles")
      .select("id")
      .eq("user_id", userId)
      .eq("role", "admin")
      .maybeSingle(),
    supabase
      .from("profiles")
      .select("role")
      .eq("id", userId)
      .maybeSingle(),
  ]);

  if (Boolean(roleRow) || profileRow?.role === "admin") return true;
  if (roleError || profileError) throw new Error("Não foi possível verificar seu acesso ao painel. Tente novamente.");
  return false;
};