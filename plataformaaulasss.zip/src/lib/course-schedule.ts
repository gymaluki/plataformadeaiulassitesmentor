import { supabase } from "@/integrations/supabase/client";

export interface CourseSchedule {
  member_email: string | null;
  course_start_at: string | null;
  course_start_date: string | null;
  current_course_date: string | null;
  unlocked_days: number;
}

export interface ScheduleModule {
  id: string;
  title: string;
  order_index: number | null;
  is_private?: boolean;
  release_day?: number;
}

export const isExtensionModule = (title?: string | null) => {
  if (!title) return false;
  const t = title.toLowerCase();
  return t.includes("instalar a extens") || t.includes("instalar extens");
};

export const getCourseSchedule = async (): Promise<CourseSchedule> => {
  let data: any = null;
  let error: any = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    ({ data, error } = await (supabase as any)
      .rpc("get_member_course_schedule")
      .maybeSingle());
    if (!error) break;
    await new Promise((r) => setTimeout(r, 600 * (attempt + 1)));
  }

  if (error) {
    console.error("[course-schedule] schedule check failed", error);
    throw new Error("Não foi possível verificar os dias liberados. Tente novamente.");
  }

  if (!data) throw new Error("Não foi possível verificar os dias liberados. Tente novamente.");

  return {
    member_email: data?.member_email ?? null,
    course_start_at: data?.course_start_at ?? null,
    course_start_date: data?.course_start_date ?? null,
    current_course_date: data?.current_course_date ?? null,
    unlocked_days: Math.max(1, Number(data?.unlocked_days ?? 1)),
  };
};

export const getModuleDayIndex = (modules: ScheduleModule[], moduleId?: string | null) => {
  if (!moduleId) return -1;
  return modules
    .filter((module) => !isExtensionModule(module.title))
    .sort((a, b) => (a.order_index ?? 0) - (b.order_index ?? 0))
    .findIndex((module) => module.id === moduleId);
};

export const canAccessModule = (
  module: ScheduleModule | null | undefined,
  _modules: ScheduleModule[],
  unlockedDays: number,
  isAdmin = false,
) => {
  if (!module) return false;
  if (isAdmin) return true;
  if (module.is_private) return false;
  return unlockedDays >= Math.max(1, Number(module.release_day ?? 1));
};