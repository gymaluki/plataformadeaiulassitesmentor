import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  temporaryLogout: vi.fn(),
  temporaryLogin: vi.fn(),
  setSession: vi.fn(),
  mainLogout: vi.fn(),
  invoke: vi.fn(),
  getSession: vi.fn(),
  profile: vi.fn(),
}));

vi.mock("@supabase/supabase-js", () => ({ createClient: () => ({ auth: {
  signOut: mocks.temporaryLogout, signInAnonymously: mocks.temporaryLogin,
} }) }));
vi.mock("@/integrations/supabase/client", () => ({ supabase: {
  auth: { signOut: mocks.mainLogout, setSession: mocks.setSession, getSession: mocks.getSession },
  from: () => ({ select: () => ({ eq: () => ({ maybeSingle: mocks.profile }) }) }),
  functions: { invoke: mocks.invoke },
} }));

import { createAccessSession, ensureMemberSession } from "./session";

describe("member session transfer", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.temporaryLogout.mockResolvedValue({ error: null });
    mocks.mainLogout.mockResolvedValue({ error: null });
    mocks.temporaryLogin.mockResolvedValue({ data: { session: { access_token: "test-access", refresh_token: "test-refresh" } }, error: null });
    mocks.invoke.mockResolvedValue({ data: { role: "student", email: "student@example.com" }, error: null });
    mocks.setSession.mockResolvedValue({ error: null });
  });

  it("does not revoke transferred tokens after successful login", async () => {
    await createAccessSession("student@example.com", "test-password");
    expect(mocks.setSession).toHaveBeenCalledWith({ access_token: "test-access", refresh_token: "test-refresh" });
    expect(mocks.temporaryLogout).toHaveBeenCalledTimes(1);
  });

  it("rejects failed session persistence instead of reporting success", async () => {
    mocks.setSession.mockResolvedValue({ error: new Error("storage failure") });
    await expect(createAccessSession("student@example.com", "test-password")).rejects.toThrow("Não foi possível salvar seu acesso");
    expect(mocks.temporaryLogout).toHaveBeenCalledTimes(2);
  });

  it("reports a profile lookup failure instead of treating a valid session as signed out", async () => {
    mocks.getSession.mockResolvedValue({ data: { session: { user: { id: "member-id" } } } });
    mocks.profile.mockResolvedValue({ data: null, error: new Error("network failed") });
    await expect(ensureMemberSession()).rejects.toThrow("Não foi possível verificar seu acesso");
    expect(mocks.profile).toHaveBeenCalledTimes(3);
  });
});