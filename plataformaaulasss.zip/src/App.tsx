import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import Login from "./pages/live/Login";
import ModuleList from "./pages/live/ModuleList";
import LessonList from "./pages/live/LessonList";
import Player from "./pages/live/Player";
import AdminModules from "./pages/live/admin/AdminModules";
import AdminDashboardOverview from "./pages/live/admin/AdminDashboardOverview";
import AdminLessons from "./pages/live/admin/AdminLessons";
import AdminStudents from "./pages/live/admin/AdminStudents";
import AdminAccessRequests from "./pages/live/admin/AdminAccessRequests";
import NotFound from "./pages/NotFound";
import AffiliateN from "./pages/AffiliateN";
import Maintenance from "./pages/Maintenance";
import SelectedLanding from "./pages/SelectedLanding";

const queryClient = new QueryClient();

const App = () => {
  const isMaintenance = false; // Altere para false para desativar

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            {isMaintenance ? (
              <>
                <Route path="*" element={<Maintenance />} />
              </>
            ) : (
              <>
                <Route path="/login" element={<Login />} />
                <Route path="/" element={<ModuleList />} />
                <Route path="/modulo/:moduleId" element={<LessonList />} />
                <Route path="/aula/:lessonId" element={<Player />} />
                <Route path="/admin" element={<AdminModules />} />
                <Route path="/admin/dashboard" element={<AdminDashboardOverview />} />
                <Route path="/admin/modulos" element={<AdminModules />} />
                <Route path="/admin/aulas" element={<AdminLessons />} />
                <Route path="/admin/alunos" element={<AdminStudents />} />
                <Route path="/admin/liberacoes" element={<AdminAccessRequests />} />
                <Route path="/n" element={<AffiliateN />} />
                <Route path="/selecionado" element={<SelectedLanding />} />
                <Route path="*" element={<NotFound />} />
              </>
            )}
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
