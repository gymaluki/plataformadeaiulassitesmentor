import { Link } from "react-router-dom";
import { BookOpen, Star, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface CourseCardProps {
  id: string;
  title: string;
  slug: string;
  description: string | null;
  thumbnail_url: string | null;
  price: number;
  level: string;
  category: string | null;
  lessonCount?: number;
  rating?: number;
}

export const CourseCard = ({
  title,
  slug,
  description,
  thumbnail_url,
  price,
  level,
  category,
  lessonCount = 0,
  rating = 5.0,
}: CourseCardProps) => {
  return (
    <div className="group overflow-hidden rounded-2xl border border-border bg-card transition-all hover:shadow-elevated">
      <Link to={`/courses/${slug}`} className="block aspect-video overflow-hidden">
        <img
          src={thumbnail_url || "/placeholder.svg"}
          alt={title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </Link>
      <div className="p-5">
        <div className="mb-3 flex items-center justify-between">
          <Badge variant="secondary" className="rounded-md font-bold uppercase tracking-wider text-[10px]">
            {level}
          </Badge>
          <div className="flex items-center gap-1 text-xs font-bold text-yellow-500">
            <Star className="h-3 w-3 fill-yellow-500" />
            {rating.toFixed(1)}
          </div>
        </div>
        <Link to={`/courses/${slug}`}>
          <h3 className="mb-2 line-clamp-1 text-lg font-black tracking-tight text-foreground group-hover:text-primary transition-colors">
            {title}
          </h3>
        </Link>
        <p className="mb-4 line-clamp-2 text-sm leading-relaxed text-muted-foreground">
          {description || "Sem descrição disponível."}
        </p>
        <div className="flex items-center justify-between border-t border-border pt-4">
          <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
            <BookOpen className="h-4 w-4" />
            {lessonCount} aulas
          </div>
          <div className="text-lg font-black text-foreground">
            {price === 0 ? "Gratuito" : `R$ ${Number(price).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          </div>
        </div>
      </div>
    </div>
  );
};
