import { LogOut, Shield, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { isAdminUser } from "@/lib/admin-access";
import { useToast } from "@/hooks/use-toast";

export const Header = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [email, setEmail] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (!session?.user?.id) {
        setEmail(null);
        setIsAdmin(false);
        return;
      }

      const { data: profile } = await supabase
        .from("profiles")
        .select("email")
        .eq("id", session.user.id)
        .maybeSingle();

      setEmail(profile?.email ?? session.user.email ?? null);
      setIsAdmin(await isAdminUser(session.user.id));
    }).catch((error) => console.error("[header] access check failed", error));
  }, []);

  const handleSignOut = async () => {
    try {
      const { error } = await supabase.auth.signOut({ scope: "local" });
      if (error) throw error;
      navigate("/login");
    } catch {
      toast({ title: "Não foi possível sair. Tente novamente.", variant: "destructive" });
    }
  };

  return (
    <header className="sticky top-0 z-40 glass-2 px-6 py-3.5">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4">
        <Link to="/" className="flex items-center gap-2.5">
          <span
            className="flex h-8 w-8 items-center justify-center rounded-[10px] text-sm font-black text-white"
            style={{ background: "var(--grad)", boxShadow: "var(--glow-sm)" }}
          >
            P
          </span>
          <span
            className="font-display text-lg font-bold tracking-tight text-transparent bg-clip-text"
            style={{ backgroundImage: "var(--grad)" }}
          >
            PROJETO
          </span>
        </Link>
        <div className="flex items-center gap-2 sm:gap-3">
          {isAdmin && (
            <Button variant="ghost" size="sm" onClick={() => navigate("/admin")} className="text-primary hover:text-primary">
              <Shield className="h-4 w-4 mr-2" />
              Admin
            </Button>
          )}
          <div className="hidden sm:flex items-center gap-2 rounded-full border border-border bg-white/[0.04] px-3 py-1.5 text-xs font-medium text-muted-foreground">
            <User className="h-3.5 w-3.5 text-primary" />
            <span className="max-w-[180px] truncate">{email || "Visitante"}</span>
          </div>
          <Button variant="ghost" size="sm" onClick={handleSignOut} className="text-muted-foreground hover:text-foreground">
            <LogOut className="h-4 w-4 sm:mr-2" />
            <span className="hidden sm:inline">Sair</span>
          </Button>
        </div>
      </div>
    </header>
  );
};

