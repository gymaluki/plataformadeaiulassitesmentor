import { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { WelcomeVideoGate } from "./WelcomeVideoGate";

const mocks = vi.hoisted(() => ({ rpc: vi.fn() }));
vi.mock("@/integrations/supabase/client", () => ({ supabase: {
  auth: { getSession: async () => ({ data: { session: { user: { id: "student-1", email: "student@example.com" } } } }) },
  from: () => ({ select: () => ({ eq: () => ({
    maybeSingle: async () => ({ data: { email: "student@example.com" } }),
    limit: async () => ({ data: [] }),
  }) }) }),
  rpc: mocks.rpc,
} }));

type Events = { onReady: (event: unknown) => void; onError: () => void; onStateChange: (event: { data: number }) => void };
let events: Events;
let root: Root;
let host: HTMLDivElement;
let players: number;

const flush = () => act(async () => { await new Promise(resolve => setTimeout(resolve, 20)); });

beforeEach(async () => {
  Object.assign(globalThis, { IS_REACT_ACT_ENVIRONMENT: true });
  localStorage.clear();
  vi.clearAllMocks();
  players = 0;
  mocks.rpc.mockImplementation(async (name: string) => ({ data: name === "has_watched_welcome_video" ? false : null, error: null }));
  window.YT = { Player: class {
    constructor(_host: HTMLElement, options: { events: Events }) { events = options.events; players++; }
    destroy() {}
    stopVideo() {}
  } };
  host = document.createElement("div");
  document.body.appendChild(host);
  root = createRoot(host);
  await act(async () => { root.render(<WelcomeVideoGate />); });
  await flush();
});

afterEach(async () => {
  await act(async () => root.unmount());
  host.remove();
  delete window.YT;
});

describe("mandatory welcome video", () => {
  it("does not save a failed player as watched and allows a new attempt", async () => {
    await act(async () => events.onError());
    expect(localStorage.getItem("welcome_video_done_student-1")).toBeNull();
    expect(mocks.rpc.mock.calls.filter(([name]) => name === "mark_welcome_video_watched")).toHaveLength(0);
    expect(host.querySelector<HTMLButtonElement>("button[disabled]")?.disabled).toBe(true);
    const retry = host.querySelector<HTMLButtonElement>("[role=alert] button");
    expect(retry).not.toBeNull();
    await act(async () => retry?.click());
    await flush();
    expect(players).toBe(2);
  });

  it("saves a genuinely ended video once and enables entry", async () => {
    await act(async () => events.onStateChange({ data: 0 }));
    await flush();
    expect(localStorage.getItem("welcome_video_done_student-1")).toBe("1");
    expect(mocks.rpc.mock.calls.filter(([name]) => name === "mark_welcome_video_watched")).toEqual([
      ["mark_welcome_video_watched", { _user_id: "student-1", _email: "student@example.com" }],
    ]);
    expect(host.querySelector<HTMLButtonElement>("button")?.disabled).toBe(false);
  });

  it("does not record completion when checking watched status fails and allows retry", async () => {
    mocks.rpc.mockImplementation(async () => ({ data: null, error: new Error("offline") }));
    await act(async () => { root.render(<WelcomeVideoGate key="status-failure" />); });
    await flush();
    expect(mocks.rpc.mock.calls.filter(([name]) => name === "mark_welcome_video_watched")).toHaveLength(0);
    expect(host.querySelector('[role="alert"]')).not.toBeNull();
    mocks.rpc.mockImplementation(async (name: string) => ({ data: name === "has_watched_welcome_video" ? false : null, error: null }));
    await act(async () => { host.querySelector<HTMLButtonElement>("button")?.click(); });
    await flush();
    expect(host.querySelector('[role="alert"]')).toBeNull();
    expect(mocks.rpc.mock.calls.filter(([name]) => name === "mark_welcome_video_watched")).toHaveLength(0);
  });

  it("keeps entry blocked after a failed completion save and retries without replaying", async () => {
    mocks.rpc.mockImplementation(async () => ({ data: null, error: new Error("offline") }));
    await act(async () => events.onStateChange({ data: 0 }));
    await flush();
    expect(host.querySelector<HTMLButtonElement>('button[disabled]')).not.toBeNull();
    expect(host.querySelector('[role="alert"]')).not.toBeNull();
    mocks.rpc.mockResolvedValue({ data: null, error: null });
    await act(async () => { host.querySelector<HTMLButtonElement>('[role="alert"] button')?.click(); });
    await flush();
    expect(host.querySelector('[role="alert"]')).toBeNull();
    expect(host.querySelector<HTMLButtonElement>("button")?.disabled).toBe(false);
    expect(mocks.rpc.mock.calls.filter(([name]) => name === "mark_welcome_video_watched")).toHaveLength(2);
  });
});