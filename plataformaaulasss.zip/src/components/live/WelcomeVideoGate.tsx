import { useEffect, useRef, useState } from "react";
import { CheckCircle2, PlayCircle, Lock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

const VIDEO_ID = "oxQFuB3l6jY";
const SEEK_TOLERANCE = 1.5;

const readDone = (key: string) => {
  try { return localStorage.getItem(key) === "1"; } catch { return false; }
};
const storeDone = (key: string) => {
  try { localStorage.setItem(key, "1"); } catch { /* The remote record remains authoritative. */ }
};

declare global {
  interface Window {
    YT?: any;
    onYouTubeIframeAPIReady?: () => void;
  }
}

export const WelcomeVideoGate = () => {
  const [userId, setUserId] = useState<string | null>(null);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [show, setShow] = useState(false);
  const [checking, setChecking] = useState(true);
  const [finished, setFinished] = useState(false);
  const [videoError, setVideoError] = useState(false);
  const [loadAttempt, setLoadAttempt] = useState(0);
  const [statusError, setStatusError] = useState(false);
  const [statusAttempt, setStatusAttempt] = useState(0);
  const [saveError, setSaveError] = useState(false);
  const [saved, setSaved] = useState(false);
  const [saveAttempt, setSaveAttempt] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const playerRef = useRef<any>(null);
  const maxTimeRef = useRef(0);
  const durationRef = useRef(0);
  const pollRef = useRef<number | null>(null);
  const savedRef = useRef(false);

  useEffect(() => {
    let mounted = true;
    const checkStatus = async () => {
      setChecking(true);
      setStatusError(false);
      try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session || !mounted) return;
      
      const uid = session.user.id;
      setUserId(uid);

      let email = "";
      // Retry profile fetch to ensure we get the email
      for (let attempt = 0; attempt < 3; attempt++) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("email")
          .eq("id", uid)
          .maybeSingle();
        
        email = (profile?.email || session.user.email || "").trim().toLowerCase();
        if (email) break;
        if (attempt < 2) await new Promise(r => setTimeout(r, 800));
      }

      if (!mounted) return;
      if (!email) throw new Error("Não foi possível identificar seu cadastro.");

      setUserEmail(email);
      const localKey = `welcome_video_done_${uid}`;
      const emailLocalKey = `welcome_video_done_email_${email}`;

      const { data, error } = await (supabase as any)
        .rpc("has_watched_welcome_video", { _user_id: uid, _email: email });

      if (!error && data) {
        storeDone(localKey);
        storeDone(emailLocalKey);
        return;
      }

      // A failed lookup is not evidence of an unwatched video.
      if (error) {
        throw error;
      }

      // Confere direto na tabela, caso exista registro em outro cadastro do mesmo e-mail.
      const { data: rows, error: rowsError } = await (supabase as any)
        .from("welcome_video_views")
        .select("email")
        .eq("email", email)
        .limit(1);
      if (rowsError) throw rowsError;

      if (rows && rows.length > 0) {
        storeDone(localKey);
        storeDone(emailLocalKey);
        return;
      }

      if (readDone(localKey) || readDone(emailLocalKey)) {
        const { error: saveFailure } = await (supabase as any).rpc("mark_welcome_video_watched", { _user_id: uid, _email: email });
        if (saveFailure) throw saveFailure;
        return;
      }

      setShow(true);
      } catch (error) {
        console.error("[welcome-video] status failed", error);
        if (mounted) setStatusError(true);
      } finally {
        if (mounted) setChecking(false);
      }
    };


    checkStatus();
    return () => { mounted = false; };
  }, [statusAttempt]);

  useEffect(() => {
    if (show || statusError || checking) {
      const prev = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = prev;
      };
    }
  }, [show, statusError, checking]);

  useEffect(() => {
    if (!show) return;

    let cancelled = false;
    let ready = false;
    setVideoError(false);
    const timeout = window.setTimeout(() => {
      if (!cancelled && !ready) setVideoError(true);
    }, 15000);

    const loadApi = () =>
      new Promise<void>((resolve) => {
        if (window.YT && window.YT.Player) {
          resolve();
          return;
        }
        let existing = document.querySelector<HTMLScriptElement>(
          'script[src="https://www.youtube.com/iframe_api"]'
        );
        if (loadAttempt > 0 && existing) {
          existing.remove();
          existing = null;
        }
        const onReady = () => resolve();
        const prevCb = window.onYouTubeIframeAPIReady;
        window.onYouTubeIframeAPIReady = () => {
          prevCb?.();
          onReady();
        };
        if (!existing) {
          const tag = document.createElement("script");
          tag.src = "https://www.youtube.com/iframe_api";
          document.head.appendChild(tag);
        }
      });

    loadApi().then(() => {
      if (cancelled || !containerRef.current) return;

      const playerHost = document.createElement("div");
      containerRef.current.replaceChildren(playerHost);
      playerRef.current = new window.YT.Player(playerHost, {
        videoId: VIDEO_ID,
        playerVars: {
          rel: 0,
          modestbranding: 1,
          iv_load_policy: 3,
          controls: 0,
          disablekb: 1,
          fs: 0,
          playsinline: 1,
          showinfo: 0,
        },
        events: {
          onReady: (e: any) => {
            ready = true;
            window.clearTimeout(timeout);
            setVideoError(false);
            durationRef.current = e.target.getDuration() || 0;
            if (pollRef.current) window.clearInterval(pollRef.current);
            pollRef.current = window.setInterval(() => {
              const p = playerRef.current;
              if (!p || typeof p.getCurrentTime !== "function") return;
              const t = p.getCurrentTime() as number;
              const dur = (durationRef.current ||= p.getDuration() || 0);

              if (t > maxTimeRef.current + SEEK_TOLERANCE) {
                p.seekTo(maxTimeRef.current, true);
                return;
              }
              if (t > maxTimeRef.current) {
                maxTimeRef.current = t;
              }
              if (dur > 0 && (t >= dur - 3 || maxTimeRef.current >= dur * 0.97)) {
                setFinished(true);
              }
            }, 500);
          },
          onStateChange: (e: any) => {
            if (e.data === 0) {
              setFinished(true);
              try { playerRef.current?.stopVideo?.(); } catch { /* ignore */ }
            }
          },
          onError: () => {
            window.clearTimeout(timeout);
            if (pollRef.current) {
              window.clearInterval(pollRef.current);
              pollRef.current = null;
            }
            setVideoError(true);
          },
        },
      });
    }).catch((error) => {
      console.error("[welcome-video] initialization failed", error);
      if (!cancelled) {
        window.clearTimeout(timeout);
        setVideoError(true);
      }
    });

    return () => {
      cancelled = true;
      window.clearTimeout(timeout);
      if (pollRef.current) {
        window.clearInterval(pollRef.current);
        pollRef.current = null;
      }
      try {
        playerRef.current?.destroy?.();
      } catch {
        // ignore
      }
      playerRef.current = null;
      maxTimeRef.current = 0;
      durationRef.current = 0;
    };
  }, [show, loadAttempt]);

  useEffect(() => {
    if (!finished) return;
    if (pollRef.current) {
      window.clearInterval(pollRef.current);
      pollRef.current = null;
    }
    try { playerRef.current?.stopVideo?.(); } catch { /* ignore */ }
    try { playerRef.current?.destroy?.(); } catch { /* ignore */ }
    playerRef.current = null;

    // Salva a conclusão assim que o vídeo termina. O aluno não depende mais
    // do clique no botão nem da resposta da rede para liberar a plataforma.
    if (savedRef.current || !userId) return;
    setSaveError(false);
    storeDone(`welcome_video_done_${userId}`);
    if (userEmail) storeDone(`welcome_video_done_email_${userEmail}`);
    void (supabase as any)
      .rpc("mark_welcome_video_watched", { _user_id: userId, _email: userEmail })
      .then(({ error }: { error?: unknown }) => {
        if (error) throw error;
        savedRef.current = true;
        setSaved(true);
      }).catch((error: unknown) => {
        console.error("[welcome-video] save failed", error);
        setSaveError(true);
      });
  }, [finished, userId, userEmail, saveAttempt]);

  const handleUnlock = () => {
    if (!finished || !userId || !savedRef.current) {
      if (finished) setSaveError(true);
      return;
    }
    storeDone(`welcome_video_done_${userId}`);
    if (userEmail) storeDone(`welcome_video_done_email_${userEmail}`);
    setShow(false);
  };

  if (checking) return <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background p-6 text-foreground" role="status">Verificando seu acesso...</div>;

  if (statusError) return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center gap-4 bg-background p-6 text-center text-foreground" role="alert">
      <p>Não foi possível verificar o vídeo inicial. Seu histórico não foi alterado.</p>
      <Button onClick={() => setStatusAttempt(value => value + 1)}>Tentar verificar novamente</Button>
    </div>
  );

  if (!show) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-md p-3 sm:p-6 overflow-y-auto">
      <div className="w-full max-w-4xl my-auto">
        <div className="mb-4 sm:mb-6 text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.2em] text-primary mb-3">
            <PlayCircle className="h-3.5 w-3.5" />
            Boas-vindas · Assista antes de começar
          </span>
          <h2 className="text-2xl sm:text-4xl font-bold tracking-tight text-white">
            Antes de qualquer coisa: assista esse vídeo
          </h2>
          <p className="mt-2 text-sm sm:text-base text-white/70 max-w-2xl mx-auto">
            Nele eu conto o CRONOGRAMA que eu montei pra quem entrou no projeto e além disso como realmente vai funcionar e o que você tem que seguir antes de realmente ser liberado pro restante das aulas.
          </p>
        </div>

        {finished ? (
          <div className="relative aspect-video w-full overflow-hidden rounded-2xl bg-gradient-to-br from-primary/20 via-black to-primary/10 shadow-2xl ring-1 ring-primary/30 flex flex-col items-center justify-center text-center px-6">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/20 border border-primary/40 mb-4">
              <CheckCircle2 className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-white mb-2">Vídeo concluído!</h3>
            <p className="text-sm sm:text-base text-white/70 max-w-md">
              Agora você pode liberar o acesso à plataforma e começar o cronograma.
            </p>
          </div>
        ) : (
          <div className="relative aspect-video w-full overflow-hidden rounded-2xl bg-black shadow-2xl ring-1 ring-white/10">
            <div ref={containerRef} className="absolute inset-0 h-full w-full" />
            <div className="pointer-events-auto absolute bottom-0 left-0 right-0 h-10 bg-transparent" />
            {videoError && (
              <div role="alert" className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-background p-6 text-center text-foreground">
                <p>O vídeo não carregou. Verifique sua conexão e tente novamente.</p>
                <Button onClick={() => setLoadAttempt((attempt) => attempt + 1)}>Tentar carregar o vídeo novamente</Button>
              </div>
            )}
          </div>
        )}

        <div className="mt-5 sm:mt-6 flex flex-col items-center gap-3">
          {saveError && <div role="alert" className="flex flex-col items-center gap-3 text-foreground">
            <p className="text-sm">O vídeo terminou, mas não foi possível salvar. Você não precisa assistir novamente.</p>
            <Button onClick={() => setSaveAttempt(value => value + 1)}>Tentar salvar conclusão novamente</Button>
          </div>}
          <Button
            type="button"
            onClick={handleUnlock}
            disabled={!finished || !saved}
            className={`inline-flex items-center justify-center gap-2 rounded-xl px-6 py-3 text-sm font-bold uppercase tracking-[0.16em] transition-all ${
              finished
                ? "bg-primary text-primary-foreground hover:shadow-glow hover:-translate-y-0.5 cursor-pointer"
                : "bg-white/10 text-white/50 cursor-not-allowed"
            }`}
          >
            {finished ? (
              <>
                <CheckCircle2 className="h-4 w-4" />
                Liberar acesso à plataforma
              </>
            ) : (
              <>
                <Lock className="h-4 w-4" />
                Termine o vídeo para liberar
              </>
            )}
          </Button>
          <p className="text-[11px] text-white/50 text-center max-w-md">
            Não é possível pular o vídeo. O botão libera automaticamente assim que o vídeo terminar.
          </p>
        </div>
      </div>
    </div>
  );
};
