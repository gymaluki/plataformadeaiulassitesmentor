import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";

const links = [
  ["/admin/modulos", "Módulos"],
  ["/admin/aulas", "Aulas"],
  ["/admin/alunos", "Alunos"],
  ["/admin/liberacoes", "Liberações"],
] as const;

export const AdminMobileNav = () => {
  const { pathname } = useLocation();
  return (
    <nav aria-label="Painel administrativo" className="mb-6 grid grid-cols-2 gap-2 md:hidden">
      {links.map(([path, label]) => (
        <Button key={path} asChild size="sm" variant={pathname === path || (path === "/admin/modulos" && pathname === "/admin") ? "default" : "outline"}>
          <Link to={path}>{label}</Link>
        </Button>
      ))}
    </nav>
  );
};