import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";

export const LoadError = ({ message, retry }: { message: string; retry: () => void }) => (
  <div role="alert" className="mb-6 flex flex-wrap items-center gap-3 rounded-lg border border-destructive/30 bg-destructive/10 p-4 text-foreground">
    <p className="min-w-0 flex-1 text-sm">{message}</p>
    <Button variant="outline" size="sm" onClick={retry}>
      <RefreshCw className="h-4 w-4" /> Tentar novamente
    </Button>
  </div>
);