import React, { useEffect, useState } from "react";
import { AreaChart, Area, ResponsiveContainer, LineChart, Line } from "recharts";

const dataReceita = [
  { name: "1", value: 12000 },
  { name: "2", value: 18000 },
  { name: "3", value: 15000 },
  { name: "4", value: 22000 },
  { name: "5", value: 20000 },
  { name: "6", value: 26567 },
];

const dataPendente = [
  { name: "1", value: 1000 },
  { name: "2", value: 1500 },
  { name: "3", value: 1200 },
  { name: "4", value: 2200 },
];

const SalesDashboard = () => {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);
  return (
    <div className="grid gap-6 md:grid-cols-3">
      {/* RECEITA CARD */}
      <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-[#111] p-6 shadow-soft">
        <div className="relative z-10">
          <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground/60">Receita (Pago)</p>
          <p className="mt-1 text-3xl font-black text-white">R$ 26.567,00</p>
        </div>
        <div className="absolute inset-x-0 bottom-0 h-[100px] w-full translate-y-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={dataReceita} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="colorEmerald" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#1D9E75" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#1D9E75" stopOpacity={0} />
                </linearGradient>
              </defs>
              <Area
                type="monotone"
                dataKey="value"
                stroke="#1D9E75"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorEmerald)"
                dot={(props: any) => {
                  const { cx, cy } = props;
                  return (
                    <circle
                      key={`dot-${props.index}`}
                      cx={cx}
                      cy={cy}
                      r={2.5}
                      fill="white"
                      stroke="#1D9E75"
                      strokeWidth={1}
                    />
                  );
                }}
                isAnimationActive={true}
                animationDuration={1500}
                animationEasing="ease-in-out"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* PENDENTE CARD */}
      <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-[#111] p-6 shadow-soft">
        <div className="relative z-10">
          <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground/60">Pendente</p>
          <p className="mt-1 text-3xl font-black text-white">R$ 2.200,00</p>
        </div>
        <div className="mt-8 flex h-[60px] items-center justify-center">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={dataPendente} margin={{ top: 10, right: 20, left: 20, bottom: 10 }}>
              <Line
                type="monotone"
                dataKey="value"
                stroke="#EF9F27"
                strokeWidth={2}
                strokeDasharray="4 4"
                dot={(props: any) => {
                  const { cx, cy, index, payload } = props;
                  const isLast = index === dataPendente.length - 1;
                  return (
                    <circle
                      key={`dot-${index}`}
                      cx={cx}
                      cy={cy}
                      r={isLast ? 6 : 3}
                      fill={isLast ? "#EF9F27" : "transparent"}
                      stroke="#EF9F27"
                      strokeWidth={isLast ? 0 : 2}
                      className="animate-in fade-in zoom-in"
                      style={{ animationDelay: `${index * 200}ms`, animationFillMode: 'both' }}
                    />
                  );
                }}
                isAnimationActive={true}
                animationDuration={1500}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* TOTAL DE VENDAS CARD */}
      <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-[#111] p-6 shadow-soft">
        <div className="relative z-10">
          <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground/60">Total de Vendas</p>
          <p className="mt-1 text-3xl font-black text-white">17</p>
        </div>
        <div className="mt-2 flex flex-col items-center justify-center">
          <div className="relative h-28 w-28">
            <svg className="h-full w-full" viewBox="0 0 100 100">
              {/* Background track */}
              <path
                d="M 20 75 A 35 35 0 1 1 80 75"
                fill="none"
                stroke="#222"
                strokeWidth="6"
                strokeLinecap="round"
              />
              {/* Progress arc */}
              <path
                d="M 20 75 A 35 35 0 1 1 80 75"
                fill="none"
                stroke="#378ADD"
                strokeWidth="6"
                strokeLinecap="round"
                strokeDasharray="180"
                strokeDashoffset={mounted ? 180 - (180 * (17 / 25)) : 180}
                className="transition-all duration-1000 ease-out"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center pt-6">
              <span className="text-[10px] font-bold text-muted-foreground/80">+4 este mês</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SalesDashboard;
