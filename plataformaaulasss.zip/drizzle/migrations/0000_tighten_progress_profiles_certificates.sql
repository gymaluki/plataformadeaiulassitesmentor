DROP POLICY IF EXISTS "Anyone can manage own progress" ON public.app_progress;
CREATE POLICY "Users manage own progress" ON public.app_progress FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Public profiles are viewable by everyone" ON public.profiles;
CREATE POLICY "Users view own profile" ON public.profiles FOR SELECT TO authenticated
  USING (auth.uid() = id OR public.is_admin(auth.uid()));
UPDATE public.profiles SET temp_password_hint = NULL;
ALTER TABLE public.profiles ALTER COLUMN temp_password_hint DROP DEFAULT;
COMMENT ON COLUMN public.profiles.temp_password_hint IS 'DEPRECATED: unused, do not store passwords';

DROP POLICY IF EXISTS "Anyone can view certificates by code" ON public.certificates;